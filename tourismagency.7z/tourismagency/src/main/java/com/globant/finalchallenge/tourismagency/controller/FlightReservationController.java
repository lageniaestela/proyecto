package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.FlightReservationDTORequest;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("flight-reservations")
public class FlightReservationController {
    private final IFlightReservationService flightReservationService;

    public FlightReservationController(IFlightReservationService flightReservationService) {
        this.flightReservationService = flightReservationService;
    }
    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<List<FlightReservationDTO>> getFlightReservations() {
        return ResponseEntity.ok()
                .body(flightReservationService.findAll());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<FlightReservationDTO> getFlightReservation(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(flightReservationService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_EMPLOYEE', 'ROLE_CLIENT')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveFlightReservation(@RequestBody @Validated FlightReservationDTORequest hotelBookingDTO) {
        SimpleCRUDResponseDTO responseDTO = flightReservationService.save(hotelBookingDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ROLE_EMPLOYEE', 'ROLE_CLIENT')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateFlightReservation(
            @PathVariable Long id,
            @RequestBody @Validated FlightReservationDTORequest hotelBookingDTORequest
    ) {
        SimpleCRUDResponseDTO responseDTO = flightReservationService.update(id, hotelBookingDTORequest);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteFlightReservation(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = flightReservationService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
