package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.FlightReservationDTORequest;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.ReservationDTORequest;
import com.globant.finalchallenge.tourismagency.error_handling.exception.FlightPackageIsAlreadyReservedException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.PeopleAmountDoesNotMatchPeopleListException;
import com.globant.finalchallenge.tourismagency.model.*;
import com.globant.finalchallenge.tourismagency.repository.IFlightReservationRepository;
import com.globant.finalchallenge.tourismagency.service.contract.*;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import com.globant.finalchallenge.tourismagency.util.payments.PaymentCalculator;
import com.globant.finalchallenge.tourismagency.util.payments.SimplePaymentRepresentation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FlightReservationServiceImpl implements IFlightReservationService {
    private final IFlightReservationRepository flightReservationRepository;
    private final IPersonService personService;
    private final IApiUserService apiUserService;
    private final IPaymentMethodService paymentMethodService;
    private final IPaymentService paymentService;
    private final IFlightReservationPersonService flightReservationPersonService;
    private final IFlightPackageService flightPackageService;
    private final ModelMapper modelMapper;

    public FlightReservationServiceImpl(IFlightReservationRepository flightReservationRepository, IPersonService personService, IApiUserService apiUserService, IPaymentMethodService paymentMethodService,
                                        IPaymentService paymentService, IFlightReservationPersonService flightReservationPersonService,
                                        IFlightPackageService flightPackageService, ModelMapper modelMapper) {
        this.flightReservationRepository = flightReservationRepository;
        this.personService = personService;
        this.apiUserService = apiUserService;
        this.paymentMethodService = paymentMethodService;
        this.paymentService = paymentService;
        this.flightReservationPersonService = flightReservationPersonService;
        this.flightPackageService = flightPackageService;
        this.modelMapper = modelMapper;
    }

    @Override
    public FlightReservationDTO findById(Long id) {
        Optional<FlightReservation> result = flightReservationRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("FlightReservation", id.toString());

        return modelMapper.map(result.get(), FlightReservationDTO.class);
    }

    @Override
    public List<FlightReservationDTO> findAll() {
        List<FlightReservation> flightReservations = flightReservationRepository.findAll();

        if (flightReservations.isEmpty())
            throw new NoItemsMatchQueryException("flightReservations");

        return flightReservations.stream()
                .map(hotel -> modelMapper.map(hotel, FlightReservationDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(FlightReservationDTORequest flightReservationDTORequest) {
        ReservationDTORequest reservationDTORequest = flightReservationDTORequest.getFlightReservation();
        validatePeopleAndSeats(reservationDTORequest);

        FlightPackage flightPackage = flightPackageService.findByFlightPackageNumber(reservationDTORequest.getFlightNumber()).
                                        orElseThrow(() -> new ItemNotFoundException("FlightPackage", reservationDTORequest.getFlightNumber()));
        validateReservation(flightPackage);

        Payment payment = createPayment(flightPackage, reservationDTORequest);
        FlightReservation flightReservation = createFlightReservation(flightReservationDTORequest,
                flightPackage, payment);
        List<FlightReservationPerson> flightReservationPeople = createFlightReservationPerson(reservationDTORequest,
                flightReservation);

        // Saving flight reservation with person List
        flightReservation.setFlightReservationPersonList(flightReservationPeople);
        flightReservationRepository.save(flightReservation);

        // Saving payment with flight reservation
        payment.setFlightReservation(flightReservation);
        paymentService.save(payment);

        // Saving reserved package.
        flightPackage.setReserved(true);
        flightPackageService.save(flightPackage);

        return GlobalHelper.createResponse(
                "FlightReservation",
                flightReservation.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    private Payment createPayment (FlightPackage flightPackage, ReservationDTORequest reservationDTORequest){
        SimplePaymentRepresentation spr = PaymentCalculator.calculateFlightPayment(
                flightPackage, reservationDTORequest.getPaymentMethod());
        PaymentMethod paymentMethod = paymentMethodService.createPaymentFromDTO(reservationDTORequest.getPaymentMethod());
        return paymentService.createPayment(spr, paymentMethod, null,null);
    }
    private FlightReservation createFlightReservation(FlightReservationDTORequest flightReservationDTORequest,
                                                      FlightPackage flightPackage, Payment payment){
        ApiUser apiUser = apiUserService.findByUserName(flightReservationDTORequest.getUserName());
        return flightReservationRepository.save(new FlightReservation(
                        null, LocalDate.now(),flightPackage,payment,apiUser,null));
    }
    private List<FlightReservationPerson> createFlightReservationPerson (ReservationDTORequest reservationDTORequest,
                                                                   FlightReservation flightReservation){
        List<Person> people = personService.conditionallyPersistPeople(reservationDTORequest.getPeople());
        return flightReservationPersonService.createFlightReservationPeople(people, flightReservation);
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, FlightReservationDTORequest flightReservationDTORequest) {
        FlightReservation flightReservation = flightReservationRepository.findById(id)
                .orElseThrow(() -> new ItemNotFoundException("FlightReservation", id.toString()));
        ReservationDTORequest reservationDTORequest = flightReservationDTORequest.getFlightReservation();

        FlightPackage flightPackage = flightPackageService.findByFlightPackageNumber(reservationDTORequest.getFlightNumber()).
                orElseThrow(() -> new ItemNotFoundException("FlightPackage", reservationDTORequest.getFlightNumber()));

        SimplePaymentRepresentation spr = PaymentCalculator.calculateFlightPayment(
                flightPackage, reservationDTORequest.getPaymentMethod()
        );

        PaymentMethod paymentMethod = paymentMethodService.createPaymentFromDTO(reservationDTORequest.getPaymentMethod());
        paymentService.updatePayment(flightReservation.getPayment(), paymentMethod,spr);

        return GlobalHelper.createResponse(
                "FlightReservation",
                flightReservation.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<FlightReservation> FlightReservation = flightReservationRepository.findById(id);

        if (FlightReservation.isEmpty())
            throw new ItemNotFoundException("FlightReservation", id.toString());

        flightReservationRepository.deleteById(FlightReservation.get().getId());
        return GlobalHelper.createResponse(
                "FlightReservation",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    private void validatePeopleAndSeats(ReservationDTORequest reservationReq) {
        if (reservationReq.getPeople().size() != reservationReq.getSeats())
            throw new PeopleAmountDoesNotMatchPeopleListException(
                    reservationReq.getSeats(),
                    reservationReq.getPeople().size()
            );
    }
    private void validateReservation(FlightPackage flightPackage) {
        if (flightPackage.isReserved())
            throw new FlightPackageIsAlreadyReservedException(flightPackage);
    }
}
