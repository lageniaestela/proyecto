package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.response.client.ClientResponseDTO;
import com.globant.finalchallenge.tourismagency.model.ApiUser;

public interface IApiUserService extends ICRUD<ApiUserDTO, ApiUserDTO> {
    ApiUser findByUserName(String userName);
    ClientResponseDTO getTopThree(Integer year);
}
