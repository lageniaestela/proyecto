package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.model.Hotel;

public abstract class HotelProvider {

    public static Hotel generateHotel(Integer i) {
        return new Hotel(
                i.longValue(),
                String.valueOf(i),
                "hotelName" + i,
                "place" + i,
                null);
    }
}
