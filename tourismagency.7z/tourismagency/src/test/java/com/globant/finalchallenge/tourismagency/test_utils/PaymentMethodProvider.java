package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.enumerator.PaymentType;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;

public abstract class PaymentMethodProvider {
    public static PaymentMethod generatePaymentMethod (){
        return new PaymentMethod(
                1L,
                "1234-1234-1234-1234",
                1,
                PaymentType.DEBIT,
                null
        );
    }
}
