package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.client.BodyClientResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.client.ClientResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.UserNameMustBeUniqueException;
import com.globant.finalchallenge.tourismagency.model.ApiUser;
import com.globant.finalchallenge.tourismagency.repository.IApiUserRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IApiUserService;
import com.globant.finalchallenge.tourismagency.util.CustomApiUserTop3Query;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ApiUserServiceImpl implements IApiUserService {
    private final IApiUserRepository apiUserRepository;
    private final ModelMapper modelMapper;

    public ApiUserServiceImpl(IApiUserRepository apiUserRepository, ModelMapper modelMapper) {
        this.apiUserRepository = apiUserRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public ApiUserDTO findById(Long id) {
        Optional<ApiUser> result = apiUserRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("ApiUser", id.toString());

        return modelMapper.map(result.get(), ApiUserDTO.class);
    }

    @Override
    public List<ApiUserDTO> findAll() {
        List<ApiUser> apiUsers = apiUserRepository.findAll();

        if (apiUsers.isEmpty())
            throw new NoItemsMatchQueryException("apiUsers");

        return apiUsers.stream()
                .map(apiUser -> modelMapper.map(apiUser, ApiUserDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(ApiUserDTO apiUserDTO) {
        validateUniqueUserName(apiUserDTO.getUserName());

        ApiUser apiUser = modelMapper.map(apiUserDTO, ApiUser.class);
        apiUser = apiUserRepository.save(apiUser);
        return GlobalHelper.createResponse(
                "ApiUser",
                apiUser.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, ApiUserDTO apiUserDTO) {
        validateOnUpdate(id, apiUserDTO.getUserName());

        ApiUser apiUser = modelMapper.map(apiUserDTO, ApiUser.class);
        apiUser.setId(id);

        apiUser = apiUserRepository.save(apiUser);
        return GlobalHelper.createResponse(
                "ApiUser",
                apiUser.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<ApiUser> apiUser = apiUserRepository.findById(id);

        if (apiUser.isEmpty())
            throw new ItemNotFoundException("apiUser", id.toString());

        apiUserRepository.deleteById(apiUser.get().getId());
        return GlobalHelper.createResponse(
                "ApiUser",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public ClientResponseDTO getTopThree(Integer year) {
        List<CustomApiUserTop3Query> results = apiUserRepository.getTopThree(year);

        List<BodyClientResponseDTO> response = new ArrayList<>();
        for (int i = 0; i < results.size();i++){
            CustomApiUserTop3Query currUser = results.get(i);
            response.add(new BodyClientResponseDTO(
                    i+1,
                    year,
                    Integer.valueOf(currUser.getBookingQuantity()),
                    new BigDecimal(currUser.getTotalAmount()),
                    Integer.valueOf(currUser.getClientId()),
                    currUser.getClientName(),
                    currUser.getClientLastName()
            ));
        }
        return new ClientResponseDTO(response);
    }

    @Override
    public ApiUser findByUserName(String userName) {
        return apiUserRepository.findByUserName(userName);
    }

    private void validateOnUpdate(Long id, String userName) {
        String currentUserName = validateUserWithIdExistsAndReturnUserName(id);

        // if current userName is equals to new userName, is valid.
        if (!currentUserName.equals(userName)) {
            validateUniqueUserName(userName);
        }
    }

    private void validateUniqueUserName(String userName) {
        if (apiUserRepository.existsByUserName(userName)) {
            throw new UserNameMustBeUniqueException(userName);
        }
    }

    private String validateUserWithIdExistsAndReturnUserName(Long id) {
        return apiUserRepository.findById(id)
                .orElseThrow(() -> new ItemNotFoundException("apiUser", id.toString()))
                .getUserName();
    }

}
