package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.HotelBookingDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.HotelBookingDTORequest;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelBookingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotel-bookings")
public class HotelBookingController {
    private final IHotelBookingService hotelBookingService;

    public HotelBookingController(IHotelBookingService hotelBookingService) {
        this.hotelBookingService = hotelBookingService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<List<HotelBookingDTO>> getHotelBookings() {
        return ResponseEntity.ok()
                .body(hotelBookingService.findAll());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<HotelBookingDTO> getHotelBooking(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(hotelBookingService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_EMPLOYEE', 'ROLE_CLIENT')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveHotelBooking(@RequestBody @Validated HotelBookingDTORequest hotelBookingDTO) {
        System.out.println(hotelBookingDTO);
        SimpleCRUDResponseDTO responseDTO = hotelBookingService.save(hotelBookingDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ROLE_EMPLOYEE', 'ROLE_CLIENT')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateHotelBooking(
            @PathVariable Long id,
            @RequestBody @Validated HotelBookingDTORequest hotelBookingDTORequest
    ) {
        SimpleCRUDResponseDTO responseDTO = hotelBookingService.update(id, hotelBookingDTORequest);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteHotelBooking(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = hotelBookingService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
