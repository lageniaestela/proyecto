package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.LoginDataDTO;
import com.globant.finalchallenge.tourismagency.repository.IAuthenticationService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/users")
public class AuthenticationController {
    private final IAuthenticationService authenticationService;

    public AuthenticationController(IAuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @PostMapping("/register")
    public ApiUserDTO register(@RequestBody @Validated LoginDataDTO loginData) {
        return authenticationService.register(loginData);
    }

    @PostMapping("/login")
    public String login(@RequestBody @Validated LoginDataDTO loginData, HttpServletResponse response) {
        return authenticationService.login(loginData, response);
    }
}
