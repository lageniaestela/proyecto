package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.enumerator.SeatType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public abstract class FlightPackageDTOProvider {
    public static FlightPackageDTO generateOneRandom() {
        return new FlightPackageDTO(
                null,
                BigDecimal.ONE,
                LocalDate.now(),
                LocalDate.now(),
                "Bogota",
                "Seattle",
                "Joe",
                false,
                SeatType.ECONOMY,
                List.of()
        );
    }
}
