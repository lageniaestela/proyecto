package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelBookingPersonDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.HotelBookingPerson;
import com.globant.finalchallenge.tourismagency.model.Person;
import com.globant.finalchallenge.tourismagency.repository.IHotelBookingPersonRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelBookingPersonService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HotelBookingPersonServiceImpl implements IHotelBookingPersonService {
    private final IHotelBookingPersonRepository hotelBookingPersonRepository;
    private final ModelMapper modelMapper;

    public HotelBookingPersonServiceImpl(IHotelBookingPersonRepository hotelBookingPersonRepository, ModelMapper modelMapper) {
        this.hotelBookingPersonRepository = hotelBookingPersonRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public HotelBookingPersonDTO findById(Long id) {
        Optional<HotelBookingPerson> result = hotelBookingPersonRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("HotelBookingPerson", id.toString());

        return modelMapper.map(result.get(), HotelBookingPersonDTO.class);
    }

    @Override
    public List<HotelBookingPersonDTO> findAll() {
        List<HotelBookingPerson> hotelBookingPersons = hotelBookingPersonRepository.findAll();

        if (hotelBookingPersons.isEmpty())
            throw new NoItemsMatchQueryException("hotelBookingPersons");

        return hotelBookingPersons.stream()
                .map(hotelBookingPerson -> modelMapper.map(hotelBookingPerson, HotelBookingPersonDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(HotelBookingPersonDTO hotelBookingPersonDTO) {
        HotelBookingPerson hotelBookingPerson = modelMapper.map(hotelBookingPersonDTO, HotelBookingPerson.class);
        hotelBookingPerson = hotelBookingPersonRepository.save(hotelBookingPerson);
        return GlobalHelper.createResponse(
                "HotelBookingPerson",
                hotelBookingPerson.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, HotelBookingPersonDTO hotelBookingPersonDTO) {
        HotelBookingPerson hotelBookingPerson = modelMapper.map(hotelBookingPersonDTO, HotelBookingPerson.class);
        hotelBookingPerson.setId(id);

        if (!hotelBookingPersonRepository.existsById(id))
            throw new ItemNotFoundException("hotelBookingPerson", id.toString());

        hotelBookingPerson = hotelBookingPersonRepository.save(hotelBookingPerson);
        return GlobalHelper.createResponse(
                "HotelBookingPerson",
                hotelBookingPerson.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<HotelBookingPerson> hotelBookingPerson = hotelBookingPersonRepository.findById(id);

        if (hotelBookingPerson.isEmpty())
            throw new ItemNotFoundException("hotelBookingPerson", id.toString());

        hotelBookingPersonRepository.deleteById(hotelBookingPerson.get().getId());
        return GlobalHelper.createResponse(
                "HotelBookingPerson",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public List<HotelBookingPerson> createHotelBookingPeople(List<Person> people, HotelBooking hotelBooking) {
        List<HotelBookingPerson> hotelBookingPeople = people.stream().map(person ->
            new HotelBookingPerson(null, person, hotelBooking)
        ).collect(Collectors.toList());

        return hotelBookingPersonRepository.saveAll(hotelBookingPeople);
    }
}
