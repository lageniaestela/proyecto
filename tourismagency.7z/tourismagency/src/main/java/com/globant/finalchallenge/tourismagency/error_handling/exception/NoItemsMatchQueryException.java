package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class NoItemsMatchQueryException extends RuntimeException {
    public NoItemsMatchQueryException(String resourceName) {
        super(String.format("No %s matches given query", resourceName));
    }
}
