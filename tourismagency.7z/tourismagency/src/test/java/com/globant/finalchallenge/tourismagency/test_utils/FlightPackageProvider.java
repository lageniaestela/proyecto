package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.enumerator.SeatType;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.FlightPackageFlight;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public abstract class FlightPackageProvider {

    public static FlightPackage generatePackage(Integer numero) {
        FlightPackageFlight flightPackageFlight = new FlightPackageFlight();
        flightPackageFlight.setFlight(FlightProvider.findById(1L));
        return
                new FlightPackage(
                numero.longValue(),
                BigDecimal.valueOf(100+numero),
                LocalDate.of(2021+numero, 12, 12),
                LocalDate.of(2021+numero, 12, 24),
                "origin" + numero,
                "destination" + numero,
                "FP-123",
                false,
                SeatType.BUSINESS,
                new FlightReservation(),
                 Arrays.asList(flightPackageFlight)
        );
    }


    public static FlightPackageDTO generatePackageDTO(Integer numero) {

        return new FlightPackageDTO(
                numero.longValue(),
                BigDecimal.valueOf(100+numero),
                LocalDate.of(2021+numero, 12, 12),
                LocalDate.of(2021+numero, 12, 24),
                "origin" + numero,
                "destination" + numero,
                "FP-123",
                false,
                SeatType.BUSINESS,
                Arrays.asList(FlightProvider.findByIdDTO(1L))
        );
    }
}
