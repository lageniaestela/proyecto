package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationPersonDTO;
import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.enumerator.RoomType;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.FlightReservationPerson;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;

import java.math.BigDecimal;
import java.time.LocalDate;


public abstract class FlightReservationPersonProvider {

    public static FlightReservationPerson generateFlightReservationPerson(Integer numero) {
        return new FlightReservationPerson(
                numero.longValue(),
                null,
                null
                );
    }

    public static FlightReservationPersonDTO generateFlightReservationPersonDTO(Integer i) {
        return new FlightReservationPersonDTO(
                i.longValue(),
                null,
                null
        );
    }
}
