package com.globant.finalchallenge.tourismagency.error_handling.exception;

import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;

public class FlightPackageIsAlreadyReservedException extends RuntimeException{
    public FlightPackageIsAlreadyReservedException(FlightPackage flightPackage) {
        super(String.format(
                "FLight package with number %s from %s to %s is already reserved",
                flightPackage.getFlightPackageNumber(),
                GlobalHelper.DATE_TIME_FORMATTER.format(flightPackage.getDateFrom()),
                GlobalHelper.DATE_TIME_FORMATTER.format(flightPackage.getDateTo())
        ));
    }
}
