package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationPersonDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.*;
import com.globant.finalchallenge.tourismagency.repository.IFlightReservationPersonRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightReservationPersonService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FlightReservationPersonServiceImpl implements IFlightReservationPersonService {
    private final IFlightReservationPersonRepository flightReservationPersonRepository;
    private final ModelMapper modelMapper;

    public FlightReservationPersonServiceImpl(IFlightReservationPersonRepository flightReservationPersonRepository, ModelMapper modelMapper) {
        this.flightReservationPersonRepository = flightReservationPersonRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public FlightReservationPersonDTO findById(Long id) {
        Optional<FlightReservationPerson> result = flightReservationPersonRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("FlightReservationPerson", id.toString());

        return modelMapper.map(result.get(), FlightReservationPersonDTO.class);
    }

    @Override
    public List<FlightReservationPersonDTO> findAll() {
        List<FlightReservationPerson> flightReservationPersons = flightReservationPersonRepository.findAll();

        if (flightReservationPersons.isEmpty())
            throw new NoItemsMatchQueryException("flightReservationPersons");

        return flightReservationPersons.stream()
                .map(flightReservationPerson -> modelMapper.map(flightReservationPerson, FlightReservationPersonDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(FlightReservationPersonDTO flightReservationPersonDTO) {
        FlightReservationPerson flightReservationPerson = modelMapper.map(flightReservationPersonDTO, FlightReservationPerson.class);
        flightReservationPerson = flightReservationPersonRepository.save(flightReservationPerson);
        return GlobalHelper.createResponse(
                "FlightReservationPerson",
                flightReservationPerson.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, FlightReservationPersonDTO flightReservationPersonDTO) {
        FlightReservationPerson flightReservationPerson = modelMapper.map(flightReservationPersonDTO, FlightReservationPerson.class);
        flightReservationPerson.setId(id);

        if (!flightReservationPersonRepository.existsById(id))
            throw new ItemNotFoundException("flightReservationPerson", id.toString());

        flightReservationPerson = flightReservationPersonRepository.save(flightReservationPerson);
        return GlobalHelper.createResponse(
                "FlightReservationPerson",
                flightReservationPerson.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<FlightReservationPerson> flightReservationPerson = flightReservationPersonRepository.findById(id);

        if (flightReservationPerson.isEmpty())
            throw new ItemNotFoundException("flightReservationPerson", id.toString());

        flightReservationPersonRepository.deleteById(flightReservationPerson.get().getId());
        return GlobalHelper.createResponse(
                "FlightReservationPerson",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public List<FlightReservationPerson> createFlightReservationPeople(List<Person> people, FlightReservation flightReservation) {
        List<FlightReservationPerson> flightReservationPerson = people.stream().map(person ->
                new FlightReservationPerson(null, person, flightReservation)
        ).collect(Collectors.toList());

        return flightReservationPersonRepository.saveAll(flightReservationPerson);
    }
}
