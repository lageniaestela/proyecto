package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.HotelWithCodeNotExists;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.PackageCannotBeEditedOrDeletedException;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;
import com.globant.finalchallenge.tourismagency.repository.IHotelPackageRepository;
import com.globant.finalchallenge.tourismagency.repository.IHotelRepository;
import com.globant.finalchallenge.tourismagency.test_utils.HotelPackageProvider;
import com.globant.finalchallenge.tourismagency.test_utils.HotelProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HotelPackageServiceImplTest {
    private static final Logger logger = LoggerFactory.getLogger(HotelPackageServiceImplTest.class);

    @Mock
    private IHotelRepository hotelRepository;
    @Mock
    private IHotelPackageRepository hotelPackageRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private HotelPackageServiceImpl hotelPackageService;
    private List<HotelPackage> hotelPackages = new ArrayList<>();
    private Hotel hotel1 = HotelProvider.generateHotel(1);
    private HotelPackage hotelPackage1 = HotelPackageProvider.generatePackage(1);
    private HotelPackage hotelPackage2 = HotelPackageProvider.generatePackage(2);
    private HotelPackage hotelPackage3 = HotelPackageProvider.generatePackage(3);
    private HotelPackageDTO hotelPackageDTO = HotelPackageProvider.generatePackageDTO(1);

    @BeforeEach
    void setUp() {

    }

    @Test
    void findByIdNotExists() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(ItemNotFoundException.class, ()->hotelPackageService.findById(1l));
        verify(hotelPackageRepository, times(1)).findById(1l);
    }

    @Test
    void findByIdOk() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        when(modelMapper.map(any(),any())).thenReturn(new HotelPackageDTO());
        //Act
        HotelPackageDTO resp = hotelPackageService.findById(1l);
        //Assert
        verify(hotelPackageRepository, times(1)).findById(1l);
        verify(modelMapper, times(1)).map(hotelPackage1,HotelPackageDTO.class);
        assertNotNull(resp);
    }

    @Test
    void findAllWhenThereAreNotPackages() {
        //Arrange
        when(hotelPackageRepository.findAll()).thenReturn(hotelPackages);
        //Act
        //Assert
        assertThrows(NoItemsMatchQueryException.class, ()->hotelPackageService.findAll());
        verify(hotelPackageRepository, times(1)).findAll();
    }

    @Test
    void findAllWhenThereArePackages() {
        //Arrange
        hotelPackages.add(hotelPackage1);
        hotelPackages.add(hotelPackage2);
        when(modelMapper.map(hotelPackage1,HotelPackageDTO.class)).thenReturn(new HotelPackageDTO());
        when(modelMapper.map(hotelPackage2,HotelPackageDTO.class)).thenReturn(new HotelPackageDTO());
        when(hotelPackageRepository.findAll()).thenReturn(hotelPackages);
        //Act
        List<HotelPackageDTO> resp = hotelPackageService.findAll();
        //Assert
        assertFalse(resp.isEmpty());
        assertEquals(2,resp.size());
        verify(hotelPackageRepository, times(1)).findAll();
        verify(modelMapper, times(2)).map(any(),any());
    }

    @Test
    void saveWhenHotelCodeNotFound() {
        //Arrange
        when(hotelRepository.findByHotelCode(any())).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(HotelWithCodeNotExists.class, ()->hotelPackageService.save(hotelPackageDTO));
        verify(hotelRepository, times(1)).findByHotelCode(any());
    }

    @Test
    void saveOk() {
        //Arrange
        HotelPackageDTO hotelPackageDTO = HotelPackageProvider.generatePackageDTO(1);
        when(hotelRepository.findByHotelCode(any())).thenReturn(Optional.of(hotel1));
        when(hotelPackageRepository.save(any())).thenReturn(hotelPackage1);
        //Act
        SimpleCRUDResponseDTO resp = hotelPackageService.save(hotelPackageDTO);
        //Assert
        verify(hotelRepository, times(1)).findByHotelCode(any());
        verify(hotelPackageRepository, times(1)).save(any());
        assertNotNull(resp);
    }

    @Test
    void updateWhenPackageNotExist() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(ItemNotFoundException.class, () -> hotelPackageService.update(1l, hotelPackageDTO));
        verify(hotelPackageRepository, times(1)).findById(any());
    }

    @Test
    void updateWhenPackageIsBooked() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        hotelPackage1.setBooked(true);
        //Act
        //Assert
        assertThrows(PackageCannotBeEditedOrDeletedException.class, ()->hotelPackageService.update(1l, hotelPackageDTO));
        verify(hotelPackageRepository, times(1)).findById(any());
    }

    @Test
    void updateWhenHotelCodeNotFound() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        when(hotelRepository.findByHotelCode(any())).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(HotelWithCodeNotExists.class, ()->hotelPackageService.update(1l, hotelPackageDTO));
        verify(hotelRepository, times(1)).findByHotelCode(any());
        verify(hotelPackageRepository, times(1)).findById(any());
    }

    @Test
    void updateOk() {
        //Arrange
        HotelPackageDTO hotelPackageDTO = HotelPackageProvider.generatePackageDTO(1);
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        when(hotelRepository.findByHotelCode(any())).thenReturn(Optional.of(hotel1));
        when(hotelPackageRepository.save(any())).thenReturn(hotelPackage1);
        //Act
        SimpleCRUDResponseDTO resp = hotelPackageService.update(1l, hotelPackageDTO);
        //Assert
        verify(hotelRepository, times(1)).findByHotelCode(any());
        verify(hotelPackageRepository, times(1)).findById(any());
        verify(hotelPackageRepository, times(1)).save(any());
        assertNotNull(resp);
    }

    @Test
    void deleteWhenPackageIsBooked() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        hotelPackage1.setBooked(true);
        //Act
        //Assert
        assertThrows(PackageCannotBeEditedOrDeletedException.class, ()->hotelPackageService.update(1l, hotelPackageDTO));
        verify(hotelPackageRepository, times(1)).findById(any());
    }

    @Test
    void deleteOk() {
        //Arrange
        when(hotelPackageRepository.findById(any())).thenReturn(Optional.of(hotelPackage1));
        doNothing().when(hotelPackageRepository).deleteById(1l);
        //Act
        SimpleCRUDResponseDTO resp = hotelPackageService.delete(1l);
        //Assert
        verify(hotelPackageRepository, times(1)).findById(any());
        verify(hotelPackageRepository, times(1)).deleteById(any());
        assertNotNull(resp);
    }

    @Test
    void lastSaveOk() {
        //Arrange
        when(hotelPackageRepository.save(any())).thenReturn(hotelPackage1);
        //Act
        HotelPackage resp = hotelPackageService.save(hotelPackage1);
        //Assert
        verify(hotelPackageRepository, times(1)).save(hotelPackage1);
    }

}