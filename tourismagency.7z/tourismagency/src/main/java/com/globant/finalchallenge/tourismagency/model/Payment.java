package com.globant.finalchallenge.tourismagency.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "payments")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal total;
    private BigDecimal withoutInterest;
    private Double interest;
    @OneToOne(mappedBy = "payment")
    private HotelBooking hotelBooking;
    @OneToOne(mappedBy = "payment")
    private FlightReservation flightReservation;
    @OneToOne(cascade = {CascadeType.REMOVE})
    @JoinColumn(name = "payment_method_id")
    private PaymentMethod paymentMethod;
}
