package com.globant.finalchallenge.tourismagency.model;

import com.globant.finalchallenge.tourismagency.enumerator.PaymentType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "payment_methods")
public class PaymentMethod {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String number;
    private Integer dues;
    @Enumerated(EnumType.STRING)
    private PaymentType paymentType;
    @OneToOne(mappedBy = "paymentMethod")
    private Payment payment;
}
