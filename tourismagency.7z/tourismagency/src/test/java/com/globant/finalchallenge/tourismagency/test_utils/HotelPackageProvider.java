package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.enumerator.RoomType;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;

import java.math.BigDecimal;
import java.time.LocalDate;


public abstract class HotelPackageProvider {

    public static HotelPackage generatePackage(Integer numero) {
        return new HotelPackage(
                numero.longValue(),
                BigDecimal.valueOf(100+numero),
                LocalDate.of(2021+numero, 12, 12),
                LocalDate.of(2021+numero, 12, 24),
                false,
                RoomType.DOUBLE,
                null,
                null
        );
    }


    public static HotelPackageDTO generatePackageDTO(Integer numero) {
        return new HotelPackageDTO(
                numero.longValue(),
                BigDecimal.valueOf(100+numero),
                LocalDate.of(2021+numero, 12, 12),
                LocalDate.of(2021+numero, 12, 24),
                RoomType.DOUBLE,
                "hotelCode" + numero
        );
    }
}
