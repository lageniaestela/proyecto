package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class RoomTypeDoesNotSupportPeopleAmountException extends RuntimeException {
    public RoomTypeDoesNotSupportPeopleAmountException(int roomTypeCapacity, int nPeople) {
        super(String.format(
                "Hotel package's room capacity (%s) does not support the number of people in booking (%s)",
                roomTypeCapacity,
                nPeople
        ));
    }
}
