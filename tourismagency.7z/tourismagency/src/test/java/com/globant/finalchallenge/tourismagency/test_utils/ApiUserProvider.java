package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.enumerator.RoleType;
import com.globant.finalchallenge.tourismagency.model.ApiUser;

import java.util.ArrayList;

public abstract class ApiUserProvider {
    public static ApiUser generateApiUser(Long id, String userName){
        return new ApiUser(
                id,
                userName,
                "1234",
                RoleType.ROLE_CLIENT,
                null,
                null,
                null
        );
    }
    public static ApiUserDTO generateApiUserDTO(Long id, String userName){
        return new ApiUserDTO(
                id,
                userName,
                "1234",
                RoleType.ROLE_CLIENT,
                null,
                null
        );
    }
}
