package com.globant.finalchallenge.tourismagency.error_handling.exception;

import com.globant.finalchallenge.tourismagency.model.HotelPackage;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;

public class HotelPackageIsAlreadyBookedException extends RuntimeException {

    public HotelPackageIsAlreadyBookedException(HotelPackage hotelPackage) {
        super(String.format(
                "Hotel package of hotel %s from %s to %s is already booked",
                hotelPackage.getHotel().getHotelName(),
                GlobalHelper.DATE_TIME_FORMATTER.format(hotelPackage.getDateFrom()),
                GlobalHelper.DATE_TIME_FORMATTER.format(hotelPackage.getDateTo())
        ));
    }
}
