package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.PaymentDTO;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.Payment;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;
import com.globant.finalchallenge.tourismagency.util.payments.SimplePaymentRepresentation;
import org.springframework.stereotype.Service;

public interface IPaymentService extends ICRUD<PaymentDTO, PaymentDTO> {
    Payment createPayment(SimplePaymentRepresentation spr,
                          PaymentMethod paymentMethod,
                          HotelBooking hotelBooking,
                          FlightReservation flightReservation);

    Payment save(Payment payment);
    Payment updatePayment(Payment payment,PaymentMethod paymentMethod,SimplePaymentRepresentation spr);
}
