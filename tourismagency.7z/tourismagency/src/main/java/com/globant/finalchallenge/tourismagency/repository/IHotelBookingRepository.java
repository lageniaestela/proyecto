package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IHotelBookingRepository extends JpaRepository<HotelBooking,Long> {
    @Query("select h from HotelBooking h where h.reservationDate = :date")
    List<HotelBooking> findByReservationDate(@Param("date") LocalDate theDate);

    @Query("select h from HotelBooking h where month(h.reservationDate) = :m " +
                                          "and year(h.reservationDate) = :y")
    List<HotelBooking> findByReservationMonthAndYear(@Param("m") Integer month, @Param("y") Integer year);
}
