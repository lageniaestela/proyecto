package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class CustomLocalDateParsingException extends RuntimeException {
    public CustomLocalDateParsingException(String parsedString, String expectedFormat, String fieldName) {
        super(String.format(
                "%s in %s does not follow the accepted format: %s",
                parsedString,
                fieldName,
                expectedFormat
        ));
    }
}
