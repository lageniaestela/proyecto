# ElCorreCaminos.com
## Presentación del Proyecto
Se desea realizar un API para una startup Latinoamericana
llamada ElCorreCaminos.com. El cliente solicita que
esta soporte sus 2 principales procesos de negocio como lo son
los **hoteles** y los **vuelos**, mediante el sitio web se debe
poder reservar ambos de estos servicios desde el lado del usuario y
por el de los empleados deben poderse administrar las diferentes
entidades del negocio mediante un CRUD.
El equipo de 5 desarrolladores contó con 4.5 días para
desarrollar el proyecto.
## Tecnologías Utilizadas
- Spring Boot
- Spring Web
- Spring Data JPA
- Spring Validations
- Spring Security
- JWT (usango JJWT)
- ModelMapper
- Lombok
- MySQL
## Seguridad
Se hace mediante jwt, hay 1 endpoint de `/api/v1/users/login`
que devuelve el Bearer token en el header del response, un ejemplo abajo:
### Para ingresar como Empleado
```
POST http://localhost:8080/api/v1/users/login
Content-Type: application/json
{
"username": "user5@mail.com",
"password": "Password123"
}
```
### Para ingresar como Usuario
```
POST http://localhost:8080/api/v1/users/login
Content-Type: application/json
{
"username": "user1@mail.com",
"password": "Password123"
}
```
### Ejemplo de token recibido
Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE2Mzk3NTY3NjIsImlzcyI6IlRyYXZlbEFnZW5jeSIsInN1YiI6InVzZXI1QG1haWwuY29tIiwicm9sZSI6IlJPTEVfRU1QTE9ZRUUiLCJleHAiOjE2NDAzNjE1NjJ9.nmNPck7CjVSPgtiv5Xdu-chXHv0Dzk80AbR2UgEKsWCRi6PlRlbFuJ7mm496KLvDqftgKTdpUWNDrZC_LTOang
## Endpoints pedidos
### POST
#### Description: Alta de hoteles
/api/v1/hotels
#### Description: Alta de reserva de hoteles
/api/v1/hotel-bookings
#### Description: Alta de vuelos
/api/v1/flights
#### Description: Alta de reserva de vuelos
/api/v1/flight-reservations
###PUT
#### Description: Modificación de un hotel
/api/v1/hotels/{id}
#### Description: Modificación de un vuelo
/api/v1/flights/{id}
#### Description: Modificación de una reserva de hotel
/api/v1/hotel-bookings/{id}
#### Description: Modificación de una reserva de vuelo
/api/v1/flight-reservations/{id}
###GET
#### Description: Listado de todos los hoteles
/api/v1/hotels
#### Description: Listado de todos los vuelos
/api/v1/flights
#### Description: Listado de todas las reservas de hotel
/api/v1/hotel-bookings/
#### Description: Listado de todas las reservas de vuelos
/api/v1/flight-reservations/
#### Description: Listado de paquetes de hoteles según filtros
/api/v1/hotel-packages?dateFrom=dd/MM/yyyy&dateTo=dd/MM/yyyy&destination=destination_name
#### Description: Listado de paquetes de vuelos según filtros
/api/v1/flight-packages?dateFrom=dd/MM/yyyy&dateTo=dd/MM/yyyy&origin=origin_name&destination=destination_name
###DELETE
#### Description: Baja de un hotel
/api/v1/hotels/{id}
#### Description: Baja de un vuelo
/api/v1/flights/{id}
#### Description: Baja de una reserva de hotel
/api/v1/hotel-bookings/{id}
#### Description: Baja de una reserva de vuelo
/api/v1/flight-reservations/{id}

## User Story 03
#### Description: Total de ingresos brutos para un día en particular a partir de reservas
/api/v1/income?date=dd/mm/yyyy

#### Description: Total de ingresos brutos para un mes y año en particular a partir de reservas
/api/v1/income?month=1&year=yyyy

## User Story 04
#### Description: Listado del top 3 de clientes enbase a cantidad de reservasrealizadas
/api/v1/clients/top-3?year=yyyy

## Endpoints adicionales
#### Description: Alta de paquete de hoteles
/api/v1/hotel-packages
#### Description: Alta de package de vuelo
/api/v1/flight-packages
#### Description: Modificación de un paquete de hotel
/api/v1/hotel-packages/{id}
#### Description: Modificación de paquete de vuelo
/api/v1/flight-packages/{id}
#### Description: Obtener un paquete de hotel
/api/v1/hotel-packages/{id}
#### Description: Obtener un paquete de vuelo
/api/v1/flight-packages/{id}
#### Description: Baja de paquete por ID
/api/v1/flight-packages/{id}


## Colaboradores
- Jose Acevedo
- Martin Bournonville
- Ferney Fonseca
- Tomas Scalbi
- Fabian Troche

## Adradecimientos
- Jose Acevedo
- Martin Bournonville
- Ferney Fonseca
- Tomas Scalbi
- Fabian Troche
- Joy Tabella
- Damian Betancur
