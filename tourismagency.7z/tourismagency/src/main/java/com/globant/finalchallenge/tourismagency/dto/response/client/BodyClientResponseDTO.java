package com.globant.finalchallenge.tourismagency.dto.response.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BodyClientResponseDTO {
    @JsonProperty("top_number")
    private Integer topNumber;
    private Integer year;
    @JsonProperty("booking_quantity")
    private Integer bookingQuantity;
    @JsonProperty("total_amount")
    private BigDecimal totalAmount;
    @JsonProperty("client_id")
    private Integer clientId;
    @JsonProperty("client_name")
    private String clientName;
    @JsonProperty("client_lastname")
    private String clientLastName;
}