package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.PaymentDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.Payment;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;
import com.globant.finalchallenge.tourismagency.repository.IPaymentRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IPaymentMethodService;
import com.globant.finalchallenge.tourismagency.service.contract.IPaymentService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import com.globant.finalchallenge.tourismagency.util.payments.SimplePaymentRepresentation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PaymentServiceImpl implements IPaymentService {
    private final IPaymentRepository paymentRepository;
    private final IPaymentMethodService paymentMethodService;
    private final ModelMapper modelMapper;

    public PaymentServiceImpl(IPaymentRepository paymentRepository, IPaymentMethodService paymentMethodService, ModelMapper modelMapper) {
        this.paymentRepository = paymentRepository;
        this.paymentMethodService = paymentMethodService;
        this.modelMapper = modelMapper;
    }

    @Override
    public PaymentDTO findById(Long id) {
        Optional<Payment> result = paymentRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("Payment", id.toString());

        return modelMapper.map(result.get(), PaymentDTO.class);
    }

    @Override
    public List<PaymentDTO> findAll() {
        List<Payment> payments = paymentRepository.findAll();

        if (payments.isEmpty())
            throw new NoItemsMatchQueryException("payments");

        return payments.stream()
                .map(payment -> modelMapper.map(payment, PaymentDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(PaymentDTO paymentDTO) {
        Payment payment = modelMapper.map(paymentDTO, Payment.class);
        payment = paymentRepository.save(payment);
        return GlobalHelper.createResponse(
                "Payment",
                payment.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, PaymentDTO paymentDTO) {
        Payment payment = modelMapper.map(paymentDTO, Payment.class);
        payment.setId(id);

        if (!paymentRepository.existsById(id))
            throw new ItemNotFoundException("payment", id.toString());

        payment = paymentRepository.save(payment);
        return GlobalHelper.createResponse(
                "Payment",
                payment.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<Payment> payment = paymentRepository.findById(id);

        if (payment.isEmpty())
            throw new ItemNotFoundException("payment", id.toString());

        paymentRepository.deleteById(payment.get().getId());
        return GlobalHelper.createResponse(
                "Payment",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public Payment createPayment(SimplePaymentRepresentation spr,
                                 PaymentMethod paymentMethod,
                                 HotelBooking hotelBooking,
                                 FlightReservation flightReservation) {
        Payment payment = new Payment(
                null, spr.getTotal(),
                spr.getWithoutInterest(),
                spr.getInterest(),
                hotelBooking,
                flightReservation,
                paymentMethod
        );

        payment.getPaymentMethod().setPayment(payment);
        return paymentRepository.save(payment);
    }

    @Override
    public Payment save(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public Payment updatePayment(Payment payment,PaymentMethod paymentMethod,SimplePaymentRepresentation spr){
        payment.setTotal(spr.getTotal());
        payment.setInterest(spr.getInterest());
        payment.setWithoutInterest(spr.getWithoutInterest());
        payment.setPaymentMethod(paymentMethod);
        return this.paymentRepository.save(payment);
    }



}
