package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.response.hotel.HotelPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface IHotelPackageService extends ICRUD <HotelPackageDTO,HotelPackageDTO> {
    HotelPackage save(HotelPackage hotelPackage);
    HotelPackageResponseDTO getAllByFilter(Optional<String> dateFrom, Optional<String> dateTo, Optional<String> destination);
}
