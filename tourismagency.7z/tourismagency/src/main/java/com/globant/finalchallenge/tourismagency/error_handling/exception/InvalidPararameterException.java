package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class InvalidPararameterException extends RuntimeException {
    public InvalidPararameterException(String message) {
        super(String.format(
                "%s",
                message
        ));
    }
}
