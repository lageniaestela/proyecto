package com.globant.finalchallenge.tourismagency.dto.request.flight_reservation;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.dto.PaymentMethodDTO;
import com.globant.finalchallenge.tourismagency.dto.PersonDTO;
import com.globant.finalchallenge.tourismagency.enumerator.SeatType;
import com.globant.finalchallenge.tourismagency.util.deserialization.CustomLocalDateDeserializer;
import com.globant.finalchallenge.tourismagency.util.deserialization.ValidatedIntegerDeserializer;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReservationDTORequest {
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate goingDate;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate returnDate;
    @NotBlank
    private String origin;
    @NotBlank
    private String destination;
    @NotBlank
    private String flightNumber;
    @NotNull
    @JsonDeserialize(using = ValidatedIntegerDeserializer.class)
    private Integer seats;
    @NotNull
    private SeatType seatType;
    @Valid
    @NotNull
    private List<PersonDTO> people;
    @Valid
    @NotNull
    private PaymentMethodDTO paymentMethod;
}
