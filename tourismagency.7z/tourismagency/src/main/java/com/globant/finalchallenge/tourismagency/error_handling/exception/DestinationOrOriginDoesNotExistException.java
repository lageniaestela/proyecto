package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class DestinationOrOriginDoesNotExistException extends RuntimeException {
    public DestinationOrOriginDoesNotExistException(String field, String value, String resource) {
        super(String.format(
                "Specified %s: %s does not exist within registered %s",
                field,
                value,
                resource
        ));
    }
}
