package com.globant.finalchallenge.tourismagency.security;

import com.globant.finalchallenge.tourismagency.model.ApiUser;
import com.globant.finalchallenge.tourismagency.repository.IApiUserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private final IApiUserRepository apiUserRepository;

    public UserDetailsServiceImpl(IApiUserRepository apiUserRepository) {
        this.apiUserRepository = apiUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ApiUser user = apiUserRepository.findByUserName(username);
        if (user == null)
            throw new UsernameNotFoundException(String.format("User %s does not exist", username));
        List<GrantedAuthority> authorities = List.of(
                new SimpleGrantedAuthority(user.getRoleType().toString())
        );
        return new User(user.getUserName(), user.getPassword(), authorities);
    }
}
