package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IFlightPackageRepository extends JpaRepository<FlightPackage, Long> {
    Optional<FlightPackage> findByFlightPackageNumber(String flightNumber);
}
