package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationDTO;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.FlightReservationDTORequest;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;

public interface IFlightReservationService extends ICRUD<FlightReservationDTORequest, FlightReservationDTO> {
}
