package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;

import java.util.List;

public interface ICRUD <REQUEST,RESPONSE>{
    RESPONSE findById(Long id);
    List<RESPONSE> findAll();
    SimpleCRUDResponseDTO save(REQUEST request);
    SimpleCRUDResponseDTO update(Long id, REQUEST request);
    SimpleCRUDResponseDTO delete(Long id);
}