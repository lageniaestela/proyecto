package com.globant.finalchallenge.tourismagency.enumerator;

import lombok.Getter;

@Getter
public enum RoomType {
    SINGLE(1),
    DOUBLE(2),
    TRIPLE(3),
    MULTIPLE(4);

    RoomType(Integer capacity) {
        this.capacity = capacity;
    }

    private final Integer capacity;
}
