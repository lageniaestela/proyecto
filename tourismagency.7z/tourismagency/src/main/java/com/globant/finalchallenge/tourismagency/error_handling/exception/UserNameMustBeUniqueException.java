package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class UserNameMustBeUniqueException extends RuntimeException{
    public UserNameMustBeUniqueException(String userName) {
        super(String.format("Unable to create new user, since user name: %s is already taken",
                userName));
    }
}
