package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.LoginDataDTO;
import com.globant.finalchallenge.tourismagency.enumerator.RoleType;
import com.globant.finalchallenge.tourismagency.error_handling.exception.security.FailedLoginException;
import com.globant.finalchallenge.tourismagency.model.ApiUser;
import com.globant.finalchallenge.tourismagency.repository.IApiUserRepository;
import com.globant.finalchallenge.tourismagency.repository.IAuthenticationService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.globant.finalchallenge.tourismagency.security.SecurityConstants.*;

@Service
public class AuthenticationServiceImpl implements IAuthenticationService {

    private final IApiUserRepository apiUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;

    public AuthenticationServiceImpl(IApiUserRepository apiUserRepository, PasswordEncoder passwordEncoder, ModelMapper modelMapper) {
        this.apiUserRepository = apiUserRepository;
        this.passwordEncoder = passwordEncoder;
        this.modelMapper = modelMapper;
    }

    @Override
    public String login(LoginDataDTO loginData, HttpServletResponse response) {
        ApiUser apiUser = apiUserRepository.findByUserName(loginData.getUsername());

        System.out.println(passwordEncoder.getClass().getName());

        if (apiUser == null)
            throw new FailedLoginException();

        if (!passwordEncoder.matches(loginData.getPassword(), apiUser.getPassword()))
            throw new FailedLoginException();

        String token = Jwts.builder().setIssuedAt(new Date()).setIssuer(ISSUER_INFO)
                .setSubject(apiUser.getUserName())
                .addClaims(Map.of("role", apiUser.getRoleType().toString()))
                .setExpiration(new Date(System.currentTimeMillis() + TOKEN_EXPIRATION_TIME))
                .signWith(SECRET_KEY, SignatureAlgorithm.HS512).compact();

        response.addHeader(HEADER_AUTHORIZARION_KEY, TOKEN_BEARER_PREFIX + token);

        return "Login successful";
    }

    @Override
    public ApiUserDTO register(LoginDataDTO loginData) {
        ApiUser apiUser = new ApiUser(
                null,
                loginData.getUsername(),
                passwordEncoder.encode(loginData.getPassword()),
                RoleType.ROLE_CLIENT,
                List.of(),
                List.of(),
                null
        );
        apiUser = apiUserRepository.save(apiUser);
        return modelMapper.map(apiUser, ApiUserDTO.class);
    }
}
