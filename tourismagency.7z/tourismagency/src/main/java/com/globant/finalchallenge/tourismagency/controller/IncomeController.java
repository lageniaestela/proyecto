package com.globant.finalchallenge.tourismagency.controller;


import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDateDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeMonthDTOResponse;
import com.globant.finalchallenge.tourismagency.service.IIncomeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping("/income")
public class IncomeController {
    private static final Logger logger = LoggerFactory.getLogger(IncomeController.class);

    private final IIncomeService incomeService;

    public IncomeController(IIncomeService incomeService) {
        this.incomeService = incomeService;
    }

    /*@GetMapping(params = "date")
    public ResponseEntity<IncomeDTOResponse> getIncomeDate(@RequestParam(name = "date", required = false) String date) {
        return ResponseEntity.ok()
                .body(incomeService.getIncomeDate(date));
    }

    @GetMapping(params = {"month", "year"})
    public ResponseEntity<IncomeDTOResponse> getIncomeMonth(
            @RequestParam(name = "month") Integer month,
            @RequestParam(name = "year") Integer year) {
        return ResponseEntity.ok()
                .body(incomeService.getIncomeMonth(month, year));
    }*/

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<IncomeDTOResponse> getIncomeDate(
            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "month", required = false) Integer month,
            @RequestParam(name = "year", required = false) Integer year){
        return ResponseEntity.ok()
                .body(incomeService.getIncome(date, month, year));
    }
}
