package com.globant.finalchallenge.tourismagency.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.validation.constraints.NotBlank;

@Getter
@AllArgsConstructor
public class LoginDataDTO {
    @NotBlank
    private String username;
    @NotBlank
    private String password;
}
