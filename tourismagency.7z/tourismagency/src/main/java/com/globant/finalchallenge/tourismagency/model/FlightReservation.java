package com.globant.finalchallenge.tourismagency.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.util.deserialization.CustomLocalDateDeserializer;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "flight_reservations")
public class FlightReservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    private LocalDate reservationDate;
    @OneToOne
    @JoinColumn(name = "flight_package_id")
    private FlightPackage flightPackage;
    @OneToOne(cascade = {CascadeType.REMOVE})
    @JoinColumn(name = "payment_id")
    private Payment payment;
    @ManyToOne
    @JoinColumn(name = "api_user_id")
    private ApiUser apiUser;
    @OneToMany(mappedBy = "flightReservation",cascade = {CascadeType.REMOVE})
    private List<FlightReservationPerson> flightReservationPersonList;
}
