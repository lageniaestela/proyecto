package com.globant.finalchallenge.tourismagency.enumerator;

public enum RoleType {
    ROLE_CLIENT, ROLE_EMPLOYEE
}
