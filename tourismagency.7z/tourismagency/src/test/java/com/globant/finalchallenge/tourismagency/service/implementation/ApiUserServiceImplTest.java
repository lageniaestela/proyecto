package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.enumerator.RoleType;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.UserNameMustBeUniqueException;
import com.globant.finalchallenge.tourismagency.model.ApiUser;
import com.globant.finalchallenge.tourismagency.repository.IApiUserRepository;
import com.globant.finalchallenge.tourismagency.test_utils.ApiUserProvider;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApiUserServiceImplTest {
    @Mock
    private IApiUserRepository apiUserRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private ApiUserServiceImpl apiUserService;
    private ApiUser apiUser;
    private ApiUser apiUser2;
    private ApiUser apiUser3;
    private ApiUserDTO apiUserDTO;
    private ApiUserDTO apiUserDTO2;
    private ApiUserDTO apiUserDTO3;
    private List<ApiUser> apiUsers = new ArrayList<>();
    private List<ApiUserDTO> apiUsersDTO = new ArrayList<>();

    @BeforeEach
    void setUp() {
        apiUser = ApiUserProvider.generateApiUser(1L, "pedrop@gmail.com");
        apiUser2 = ApiUserProvider.generateApiUser(2L, "juanc@gmail.com");
        apiUser3 = ApiUserProvider.generateApiUser(3L, "ricardoc@gmail.com");

        apiUserDTO = ApiUserProvider.generateApiUserDTO(1L, "pedrop@gmail.com");
        apiUserDTO2 = ApiUserProvider.generateApiUserDTO(2L, "juanc@gmail.com");
        apiUserDTO3 = ApiUserProvider.generateApiUserDTO(3L, "ricardoc@gmail.com");

        apiUsers.add(apiUser);
        apiUsers.add(apiUser2);
        apiUsers.add(apiUser3);

        apiUsersDTO.add(apiUserDTO);
        apiUsersDTO.add(apiUserDTO2);
        apiUsersDTO.add(apiUserDTO3);
    }

    @ParameterizedTest
    void findByIdShouldReturnAApiUser() {
        ApiUserDTO expectedResult = apiUserDTO;
        when(apiUserRepository.findById(apiUser.getId())).thenReturn(Optional.of(apiUser));
        when(modelMapper.map(Optional.of(apiUser).get(), ApiUserDTO.class)).thenReturn(apiUserDTO);

        ApiUserDTO result = apiUserService.findById(apiUserDTO.getId());

        verify(apiUserRepository, atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());


        assertAll(
                () -> assertEquals(expectedResult.getUserName(), result.getUserName()),
                () -> assertEquals(expectedResult.getRoleType(), result.getRoleType())
        );
    }

    @Test
    void findByIdShouldReturnItemNotFoundException() {
        when(apiUserRepository.findById(apiUser.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> apiUserService.findById(apiUser.getId()));
        verify(apiUserRepository, atLeastOnce()).findById(any());
    }

    @Test
    void findAllShouldReturnAllTheApiUsers() {
        List<ApiUserDTO> expectedResult = apiUsersDTO;
        when(apiUserRepository.findAll()).thenReturn(apiUsers);
        for (int i = 0; i < 3; i++) {
            when(modelMapper.map(apiUsers.get(i), ApiUserDTO.class)).thenReturn(apiUsersDTO.get(i));
        }
        List<ApiUserDTO> result = apiUserService.findAll();

        verify(apiUserRepository, atLeastOnce()).findAll();
        verify(modelMapper, atLeast(3)).map(any(), any());
        assertEquals(expectedResult.size(), result.size());
        assertEquals(expectedResult, result);
        assertEquals(expectedResult.get(2).getUserName(), result.get(2).getUserName());
    }

    @Test
    void findAllShouldReturnNoItemsMatchQuerySelection() {
        when(apiUserRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, () -> apiUserService.findAll());
        verify(apiUserRepository, atLeastOnce()).findAll();
    }

    @Test
    void saveShouldSaveAApiUserAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("ApiUser",
                apiUser.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(apiUserDTO, ApiUser.class)).thenReturn(apiUser);
        when(apiUserRepository.save(apiUser)).thenReturn(apiUser);

        SimpleCRUDResponseDTO result = apiUserService.save(apiUserDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(apiUserRepository, atLeastOnce()).save(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void saveShouldThrowUserNameMustBeUniqueException() {
        when(apiUserRepository.existsByUserName(apiUserDTO.getUserName())).thenReturn(true);
        assertThrows(UserNameMustBeUniqueException.class, () -> apiUserService.save(apiUserDTO));
    }

    @Test
    void updateShouldUpdateAApiUserAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("ApiUser",
                apiUser.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(apiUserDTO, ApiUser.class)).thenReturn(apiUser);
        when(apiUserRepository.findById(apiUserDTO.getId())).thenReturn(Optional.of(apiUser));
        when(apiUserRepository.save(apiUser)).thenReturn(apiUser);

        SimpleCRUDResponseDTO result = apiUserService.update(apiUserDTO.getId(), apiUserDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(apiUserRepository, atLeastOnce()).findById(any());
        verify(apiUserRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldReturnItemNotFoundException() {
        when(apiUserRepository.findById(apiUser.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> apiUserService.update(1L, apiUserDTO));
        verify(apiUserRepository, atLeastOnce()).findById(1L);
    }

    @Test
    void updateShouldThrowUserNameMustBeUniqueException() {
        when(apiUserRepository.existsByUserName(apiUserDTO3.getUserName())).thenReturn(true);
        when(apiUserRepository.findById(1L)).thenReturn(Optional.of(apiUser));
        assertThrows(UserNameMustBeUniqueException.class, () -> apiUserService.update(1L, apiUserDTO3));
    }

    @Test
    void deleteShouldDeleteAApiUserAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("ApiUser",
                apiUser.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(apiUserRepository.findById(apiUser.getId())).thenReturn(Optional.of(apiUser));
        doNothing().when(apiUserRepository).deleteById(apiUser.getId());

        SimpleCRUDResponseDTO result = apiUserService.delete(apiUser.getId());

        verify(apiUserRepository, atLeastOnce()).findById(any());
        verify(apiUserRepository, atLeastOnce()).deleteById(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void deleteShouldReturnItemNotFoundException() {
        when(apiUserRepository.findById(apiUser.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> apiUserService.delete(1L));
        verify(apiUserRepository, atLeastOnce()).findById(any());
    }


}