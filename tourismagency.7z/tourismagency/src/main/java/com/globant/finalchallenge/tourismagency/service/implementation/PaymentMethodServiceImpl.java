package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.PaymentMethodDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;
import com.globant.finalchallenge.tourismagency.repository.IPaymentMethodRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IPaymentMethodService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PaymentMethodServiceImpl implements IPaymentMethodService {
    private final IPaymentMethodRepository paymentMethodRepository;
    private final ModelMapper modelMapper;

    public PaymentMethodServiceImpl(IPaymentMethodRepository paymentMethodRepository, ModelMapper modelMapper) {
        this.paymentMethodRepository = paymentMethodRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public PaymentMethodDTO findById(Long id) {
        Optional<PaymentMethod> result = paymentMethodRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("PaymentMethod", id.toString());

        return modelMapper.map(result.get(), PaymentMethodDTO.class);
    }

    @Override
    public List<PaymentMethodDTO> findAll() {
        List<PaymentMethod> paymentMethods = paymentMethodRepository.findAll();

        if (paymentMethods.isEmpty())
            throw new NoItemsMatchQueryException("paymentMethods");

        return paymentMethods.stream()
                .map(paymentMethod -> modelMapper.map(paymentMethod, PaymentMethodDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(PaymentMethodDTO paymentMethodDTO) {
        PaymentMethod paymentMethod = modelMapper.map(paymentMethodDTO, PaymentMethod.class);
        paymentMethod = paymentMethodRepository.save(paymentMethod);
        return GlobalHelper.createResponse(
                "PaymentMethod",
                paymentMethod.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, PaymentMethodDTO paymentMethodDTO) {
        PaymentMethod paymentMethod = modelMapper.map(paymentMethodDTO, PaymentMethod.class);
        paymentMethod.setId(id);

        if (!paymentMethodRepository.existsById(id))
            throw new ItemNotFoundException("paymentMethod", id.toString());

        paymentMethod = paymentMethodRepository.save(paymentMethod);
        return GlobalHelper.createResponse(
                "PaymentMethod",
                paymentMethod.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<PaymentMethod> paymentMethod = paymentMethodRepository.findById(id);

        if (paymentMethod.isEmpty())
            throw new ItemNotFoundException("paymentMethod", id.toString());

        paymentMethodRepository.deleteById(paymentMethod.get().getId());
        return GlobalHelper.createResponse(
                "PaymentMethod",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public PaymentMethod createPaymentFromDTO(PaymentMethodDTO paymentMethodDTO) {
        PaymentMethod paymentMethod = new PaymentMethod(
                null, paymentMethodDTO.getNumber(),
                paymentMethodDTO.getDues(), paymentMethodDTO.getPaymentType(),
                null
        );
        return paymentMethodRepository.save(paymentMethod);
    }
}
