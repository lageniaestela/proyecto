package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.dto.response.client.BodyClientResponseDTO;
import com.globant.finalchallenge.tourismagency.model.ApiUser;
import com.globant.finalchallenge.tourismagency.util.CustomApiUserTop3Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IApiUserRepository extends JpaRepository<ApiUser, Long> {
    ApiUser findByUserName(String str);

    Boolean existsByUserName(String userName);

    @Query(value = "SELECT api_user_id AS clientId, peo.name AS clientName, peo.last_name AS clientLastName, SUM(quantity) AS bookingQuantity, SUM(total_amount) AS totalAmount " +
            "FROM ( " +
            "         SELECT hb.api_user_id, count(*) quantity, SUM(p.total) AS total_amount FROM hotel_bookings hb " +
            "             INNER JOIN payments p ON hb.payment_id = p.id " +
            "         WHERE( YEAR(hb.reservation_date) = :year)" +
            "         GROUP BY api_user_id " +
            "     UNION ALL " +
            "         SELECT fr.api_user_id, count(*) quantity, SUM(p.total) AS total_amount FROM flight_reservations fr " +
            "             INNER JOIN payments p ON fr.payment_id = p.id " +
            "         WHERE( YEAR(fr.reservation_date) = :year)" +
            "         GROUP BY api_user_id    " +
            "     ) AS total " +
            "         INNER JOIN api_users apiu ON apiu.id = api_user_id " +
            "         INNER JOIN people peo ON peo.id = apiu.person_id " +
            "GROUP BY api_user_id " +
            "ORDER BY bookingQuantity, totalAmount DESC LIMIT 3;", nativeQuery = true)
    List<CustomApiUserTop3Query> getTopThree(@Param("year") Integer year);
}
