package com.globant.finalchallenge.tourismagency.util;

import com.globant.finalchallenge.tourismagency.error_handling.exception.LocalDateFromIsAfterToException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

public abstract class DateUtil {
    private DateUtil(){};

    public static long daysDifference(LocalDate date1, LocalDate date2){
        return ChronoUnit.DAYS.between(date1, date2);
    }

    public static void validateOptionalDates(Optional<LocalDate> dateFrom, Optional<LocalDate> dateTo){
        if(dateFrom.isPresent() && dateTo.isPresent()){
            validateDates(dateFrom.get(), dateTo.get());
        }
    }

    public static void validateDates(LocalDate dateFrom, LocalDate dateTo){
        if (DateUtil.daysDifference(dateFrom, dateTo) < 0)
            throw new LocalDateFromIsAfterToException("Check-out date (" + dateTo + ") " +
                    "should be after check-in date (" + dateFrom+ ").");
    }
}

