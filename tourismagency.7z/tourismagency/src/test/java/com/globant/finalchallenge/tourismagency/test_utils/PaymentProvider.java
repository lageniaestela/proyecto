package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.PaymentDTO;
import com.globant.finalchallenge.tourismagency.model.Payment;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;
import org.springframework.security.core.parameters.P;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public abstract class PaymentProvider {
    public static Payment generateBookingDebitCardPayment (Long id){
        return new Payment(
                id,
                BigDecimal.valueOf(100),
                BigDecimal.valueOf(100),
                0.0,
                HotelBookingProvider.generateHotelBooking(1L),
                null,
                PaymentMethodProvider.generatePaymentMethod()
        );
    }
    public static PaymentDTO generateBookingDebitCardPaymentDTO (Long id){
        return new PaymentDTO(
                id,
                BigDecimal.valueOf(100),
                BigDecimal.valueOf(100),
                0.0
        );
    }
    public static List<Payment> generatePaymentList(){
        List<Payment> paymentList = new ArrayList<>();
        paymentList.add(PaymentProvider.generateBookingDebitCardPayment(1L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPayment(2L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPayment(3L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPayment(4L));

        return paymentList;
    }
    public static List<PaymentDTO> generatePaymentDTOList(){
        List<PaymentDTO> paymentList = new ArrayList<>();
        paymentList.add(PaymentProvider.generateBookingDebitCardPaymentDTO(1L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPaymentDTO(2L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPaymentDTO(3L));
        paymentList.add(PaymentProvider.generateBookingDebitCardPaymentDTO(4L));

        return paymentList;
    }
}
