package com.globant.finalchallenge.tourismagency.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.util.deserialization.CustomLocalDateDeserializer;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PersonDTO {
    @JsonIgnore
    private Long id;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    private String dni;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    private String name;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    private String lastName;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate birthDate;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    @Email(regexp = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$", message = "Email is not valid")
    private String mail;
}
