package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.PackageCannotBeEditedOrDeletedException;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.FlightPackageFlight;
import com.globant.finalchallenge.tourismagency.repository.IFlightPackageRepository;
import com.globant.finalchallenge.tourismagency.repository.IFlightRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightPackageFlightService;
import com.globant.finalchallenge.tourismagency.test_utils.FlightPackageProvider;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlightPackageServiceImplTest {

    @Mock
    private IFlightRepository flightRepository;
    @Mock
    private IFlightPackageRepository flightPackageRepository;
    @Mock
    private IFlightPackageFlightService flightPackageFlightService;
    @Mock
    private ModelMapper modelMapper;
    private FlightPackage flightPackage;
    private List<FlightPackage> flightPackageList;
    private FlightPackageDTO flightPackageDTO;
    private Flight flight;
    @InjectMocks
    private FlightPackageServiceImpl service;

    @BeforeEach
    void setUp() {
        flightPackage = FlightPackageProvider.generatePackage(1);
        flight = flightPackage.getFlightPackageFlights().get(0).getFlight();
        flightPackageDTO = FlightPackageProvider.generatePackageDTO(1);
        flightPackageList = new ArrayList<>();
        flightPackageList.add(flightPackage);
    }

    @Test
    void findByIdShouldReturnException() {
        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, ()-> service.findById(flightPackage.getId()));

        verify(flightPackageRepository, times(1)).findById(any());

    }

    @Test
    void findById() {
        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.of(flightPackage));
        when(flightRepository.findById(flight.getId())).thenReturn(Optional.of(flight));
        when(modelMapper.map(flightPackage, FlightPackageDTO.class)).thenReturn(flightPackageDTO);

        FlightPackageDTO result = service.findById(flightPackage.getId());

        verify(flightPackageRepository, times(1)).findById(any());
        verify(modelMapper, times(1)).map(any(),any());

        assertEquals(flightPackage.getId(), result.getId());

    }
    @Test
    void findAllShouldReturnException() {

        when(flightPackageRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, ()-> service.findAll());

        verify(flightPackageRepository, times(1)).findAll();

    }

    @Test
    void findAll() {
        when(flightPackageRepository.findAll()).thenReturn(flightPackageList);
        when(flightRepository.findById(flight.getId())).thenReturn(Optional.of(flight));
        when(modelMapper.map(flightPackage, FlightPackageDTO.class)).thenReturn(flightPackageDTO);
        List<FlightPackageDTO> result = service.findAll();

        verify(flightPackageRepository, times(1)).findAll();
        verify(modelMapper, times(1)).map(any(),any());

        assertEquals(flightPackageList.size(), result.size());

    }
    @Test
    void save() {
//        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackage",
//                flightPackage.getId().toString(),
//                GlobalHelper.CRUDActionType.CREATED);
//        when(flightPackageRepository.save(any())).thenReturn(flightPackage);
//        when(flightPackageFlightService.createFlightPackageFlightFromFlightDTO(any(), any())).thenReturn(null);
//        when(flightPackageRepository.save(any())).thenReturn(any());
//        SimpleCRUDResponseDTO result = service.save(flightPackageDTO);
//
//        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void update() {
//        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackage",
//                flightPackage.getId().toString(),
//                GlobalHelper.CRUDActionType.UPDATED);
//        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.of(flightPackage));
//        when(flightPackageRepository.save(any())).thenReturn(flightPackage);
//        when(flightRepository.findById(1L)).thenReturn(Optional.of(flight));
//        SimpleCRUDResponseDTO result = service.update(flightPackage.getId(),flightPackageDTO);
//
//        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldThrowException() {

        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackage",
                flightPackage.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        flightPackage.setReserved(true);
        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.of(flightPackage));

       assertThrows(PackageCannotBeEditedOrDeletedException.class, () -> service.update(flightPackage.getId(),flightPackageDTO));


    }

    @Test
    void deleteShouldThrowException() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackage",
                flightPackage.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        flightPackage.setReserved(true);
        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.of(flightPackage));

        assertThrows(PackageCannotBeEditedOrDeletedException.class, () -> service.delete(flightPackage.getId()));



    }

    @Test
    void delete() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackage",
                flightPackage.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(flightPackageRepository.findById(flightPackage.getId())).thenReturn(Optional.of(flightPackage));

        SimpleCRUDResponseDTO result = service.delete(flightPackage.getId());

        assertEquals(expectedResult.getMessage(), result.getMessage());

    }
    @Test
    void findByFlightPackageNumber() {

        when(flightPackageRepository.findByFlightPackageNumber(flightPackage.getFlightPackageNumber())).thenReturn(Optional.of(flightPackage));

        Optional<FlightPackage> result = service.findByFlightPackageNumber(flightPackage.getFlightPackageNumber());

        assertEquals(result.get().getFlightPackageNumber(),flightPackage.getFlightPackageNumber());
    }

    @Test
    void testSave() {

        when(flightPackageRepository.save(flightPackage)).thenReturn(flightPackage);

        FlightPackage result = service.save(flightPackage);

        assertEquals(result.getFlightPackageNumber(),flightPackage.getFlightPackageNumber());
    }
}