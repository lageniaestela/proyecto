package com.globant.finalchallenge.tourismagency.enumerator;

public enum SeatType {
    ECONOMY, BUSINESS
}
