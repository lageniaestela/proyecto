package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.hotel.HotelPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelPackageService;
import com.globant.finalchallenge.tourismagency.service.implementation.HotelPackageServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("hotel-packages")
public class HotelPackageController {
    private static final Logger logger = LoggerFactory.getLogger(HotelPackageController.class);

    private final IHotelPackageService hotelPackageService;

    public HotelPackageController(HotelPackageServiceImpl hotelPackageService) {
        this.hotelPackageService = hotelPackageService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<HotelPackageResponseDTO> getHotelPackages(@RequestParam(required = false) Optional<String> dateFrom,
                                                                    @RequestParam(required = false) Optional<String> dateTo,
                                                                    @RequestParam(required = false) Optional<String> destination){
            return ResponseEntity.ok()
                    .body(hotelPackageService.getAllByFilter(dateFrom,dateTo,destination));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<HotelPackageDTO> getHotelPackage(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(hotelPackageService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveHotelPackage(@RequestBody @Validated HotelPackageDTO hotelPackageDTO) {
        SimpleCRUDResponseDTO responseDTO = hotelPackageService.save(hotelPackageDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateHotelPackage(
            @PathVariable Long id,
            @RequestBody @Validated HotelPackageDTO hotelPackageDTO
    ) {
        SimpleCRUDResponseDTO responseDTO = hotelPackageService.update(id, hotelPackageDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteHotelPackage(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = hotelPackageService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
