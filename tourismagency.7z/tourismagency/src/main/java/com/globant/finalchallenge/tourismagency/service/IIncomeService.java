package com.globant.finalchallenge.tourismagency.service;

import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDateDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeMonthDTOResponse;

public interface IIncomeService {

    IncomeDTOResponse getIncome(String date, Integer month, Integer year);
}
