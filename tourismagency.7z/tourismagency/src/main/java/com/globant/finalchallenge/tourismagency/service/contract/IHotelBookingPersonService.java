package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.HotelBookingPersonDTO;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.HotelBookingPerson;
import com.globant.finalchallenge.tourismagency.model.Person;

import java.util.List;

public interface IHotelBookingPersonService extends ICRUD<HotelBookingPersonDTO, HotelBookingPersonDTO> {
    List<HotelBookingPerson> createHotelBookingPeople(List<Person> people, HotelBooking hotelBooking);
}
