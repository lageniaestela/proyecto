package com.globant.finalchallenge.tourismagency.enumerator;

public enum PaymentType {
    CREDIT, DEBIT
}
