package com.globant.finalchallenge.tourismagency.security;

import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

import java.security.Key;

public abstract class SecurityConstants {
    public static final String ISSUER_INFO = "TravelAgency";
    public static final long TOKEN_EXPIRATION_TIME = 604_800_000L;
    public static final SignatureAlgorithm SIGNATURE_ALGORITHM = SignatureAlgorithm.HS512;
    private static final String BASE_64_SECRET_KEY = "Bo2rNKoNtw+2eya9ORrsW3lcGunq3pKoL5aLA8VMLFHwhx/RfgokXPcw1VTuJE2Qp73BE92r0ixLvSweXuaIQA==";
    public static final Key SECRET_KEY = Keys.hmacShaKeyFor(
            Decoders.BASE64.decode(BASE_64_SECRET_KEY)
    ); //Keys.secretKeyFor(SIGNATURE_ALGORITHM);

    public static final String HEADER_AUTHORIZARION_KEY = "Authorization";
    public static final String TOKEN_BEARER_PREFIX = "Bearer ";
}
