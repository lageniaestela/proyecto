package com.globant.finalchallenge.tourismagency.util.payments;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SimplePaymentRepresentation {
    private BigDecimal total;
    private BigDecimal withoutInterest;
    private Double interest;
}
