package com.globant.finalchallenge.tourismagency.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HotelDTO {
    @JsonIgnore
    private Long id;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    @Pattern(regexp = "^[A-Z]{2}-[0-9]{4}$")
    private String hotelCode;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    private String hotelName;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    private String place;
}
