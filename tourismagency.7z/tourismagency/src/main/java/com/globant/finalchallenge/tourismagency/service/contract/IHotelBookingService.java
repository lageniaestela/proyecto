package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.HotelBookingDTO;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.HotelBookingDTORequest;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;

public interface IHotelBookingService extends ICRUD<HotelBookingDTORequest,HotelBookingDTO> {
    HotelBooking save(HotelBooking hotelBooking);
}
