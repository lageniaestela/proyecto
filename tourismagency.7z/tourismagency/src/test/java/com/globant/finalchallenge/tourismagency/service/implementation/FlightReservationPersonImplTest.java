package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationPersonDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.FlightReservationPerson;
import com.globant.finalchallenge.tourismagency.model.Person;
import com.globant.finalchallenge.tourismagency.repository.IFlightReservationPersonRepository;
import com.globant.finalchallenge.tourismagency.test_utils.FlightReservationPersonProvider;
import com.globant.finalchallenge.tourismagency.test_utils.FlightReservationProvider;
import com.globant.finalchallenge.tourismagency.test_utils.PersonProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FlightReservationPersonImplTest {
    private static final Logger logger = LoggerFactory.getLogger(FlightReservationPersonImplTest.class);

    @Mock
    private IFlightReservationPersonRepository flightReservationPersonRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private FlightReservationPersonServiceImpl flightReservationPersonService;
    private FlightReservationPerson flightReservationPerson1 = FlightReservationPersonProvider.generateFlightReservationPerson(1);
    private FlightReservationPerson flightReservationPerson2 = FlightReservationPersonProvider.generateFlightReservationPerson(2);
    private FlightReservationPersonDTO flightReservationPersonDTO = FlightReservationPersonProvider.generateFlightReservationPersonDTO(1);
    private Person p1 = PersonProvider.generatePerson(1);
    private FlightReservation flightReservation1 = FlightReservationProvider.generateFlightReservation(1);
    private List<FlightReservationPerson> list = new ArrayList<>();
    private List<Person> people = new ArrayList<>();

    @BeforeEach
    void setUp() {

    }

    @Test
    void findByIdNotExists() {
        //Arrange
        when(flightReservationPersonRepository.findById(any())).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(ItemNotFoundException.class, ()->flightReservationPersonService.findById(1l));
        verify(flightReservationPersonRepository, times(1)).findById(1l);
    }

    @Test
    void findByIdOk() {
        //Arrange
        when(flightReservationPersonRepository.findById(any())).thenReturn(Optional.of(flightReservationPerson1));
        when(modelMapper.map(any(),any())).thenReturn(new FlightReservationPersonDTO());
        //Act
        FlightReservationPersonDTO resp = flightReservationPersonService.findById(1l);
        //Assert
        verify(flightReservationPersonRepository, times(1)).findById(1l);
        verify(modelMapper, times(1)).map(flightReservationPerson1,FlightReservationPersonDTO.class);
        assertNotNull(resp);
    }


    @Test
    void findAllWhenThereAreNotAssociation() {
        //Arrange
        when(flightReservationPersonRepository.findAll()).thenReturn(list);
        //Act
        //Assert
        assertThrows(NoItemsMatchQueryException.class, ()->flightReservationPersonService.findAll());
        verify(flightReservationPersonRepository, times(1)).findAll();
    }

    @Test
    void findAllWhenThereAreAssociations() {
        //Arrange
        list.add(flightReservationPerson1);
        list.add(flightReservationPerson2);
        when(modelMapper.map(flightReservationPerson2,FlightReservationPersonDTO.class)).thenReturn(new FlightReservationPersonDTO());
        when(modelMapper.map(flightReservationPerson1,FlightReservationPersonDTO.class)).thenReturn(new FlightReservationPersonDTO());
        when(flightReservationPersonRepository.findAll()).thenReturn(list);
        //Act
        List<FlightReservationPersonDTO> resp = flightReservationPersonService.findAll();
        //Assert
        assertFalse(resp.isEmpty());
        assertEquals(2,resp.size());
        verify(flightReservationPersonRepository, times(1)).findAll();
        verify(modelMapper, times(2)).map(any(),any());
    }

    @Test
    void saveOk() {
        //Arrange
        when(flightReservationPersonRepository.save(any())).thenReturn(flightReservationPerson1);
        when(modelMapper.map(any(),any())).thenReturn(flightReservationPerson1);
        //Act
        SimpleCRUDResponseDTO resp = flightReservationPersonService.save(flightReservationPersonDTO);
        //Assert
        verify(flightReservationPersonRepository, times(1)).save(flightReservationPerson1);
        verify(modelMapper, times(1)).map(flightReservationPersonDTO, FlightReservationPerson.class);
        assertNotNull(resp);
    }

    @Test
    void updateWhenAssociationNotExist() {
        //Arrange
        when(flightReservationPersonRepository.existsById(1l)).thenReturn(false);
        when(modelMapper.map(any(),any())).thenReturn(flightReservationPerson1);
        //Act
        //Assert
        assertThrows(ItemNotFoundException.class, () -> flightReservationPersonService.update(1l, flightReservationPersonDTO));
        verify(modelMapper, times(1)).map(flightReservationPersonDTO, FlightReservationPerson.class);
        verify(flightReservationPersonRepository, times(1)).existsById(1l);
    }

    @Test
    void updateOk() {
        //Arrange
        when(flightReservationPersonRepository.existsById(1l)).thenReturn(true);
        when(modelMapper.map(any(),any())).thenReturn(flightReservationPerson1);
        when(flightReservationPersonRepository.save(any())).thenReturn(flightReservationPerson1);
        //Act
        SimpleCRUDResponseDTO resp = flightReservationPersonService.update(1l, flightReservationPersonDTO);
        //Assert
        verify(flightReservationPersonRepository, times(1)).existsById(1l);
        verify(flightReservationPersonRepository, times(1)).save(any());
        verify(modelMapper, times(1)).map(flightReservationPersonDTO,FlightReservationPerson.class);
        assertNotNull(resp);
    }

    @Test
    void deleteWhenAssociationNotExist() {
        //Arrange
        when(flightReservationPersonRepository.findById(1l)).thenReturn(Optional.empty());
        //Act
        //Assert
        assertThrows(ItemNotFoundException.class, ()->flightReservationPersonService.delete(1l));
        verify(flightReservationPersonRepository, times(1)).findById(1l);
    }

    @Test
    void deleteOk() {
        //Arrange
        when(flightReservationPersonRepository.findById(any())).thenReturn(Optional.of(flightReservationPerson1));
        doNothing().when(flightReservationPersonRepository).deleteById(1l);
        //Act
        SimpleCRUDResponseDTO resp = flightReservationPersonService.delete(1l);
        //Assert
        verify(flightReservationPersonRepository, times(1)).findById(any());
        verify(flightReservationPersonRepository, times(1)).deleteById(any());
        assertNotNull(resp);
    }

    @Test
    void createFlightReservationPeople() {
        //Arrange
        people.add(p1);
        when(flightReservationPersonRepository.saveAll(any())).thenReturn(list);
        //Act
        List<FlightReservationPerson> resp = flightReservationPersonService.createFlightReservationPeople(people,flightReservation1);
        //Assert
        verify(flightReservationPersonRepository, times(1)).saveAll(any());
        assertNotNull(resp);
    }
}