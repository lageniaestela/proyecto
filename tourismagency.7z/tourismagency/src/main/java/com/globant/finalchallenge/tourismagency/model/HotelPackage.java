package com.globant.finalchallenge.tourismagency.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.enumerator.RoomType;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hotel_packages")
public class HotelPackage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal roomPrice;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    private LocalDate dateFrom;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    private LocalDate dateTo;
    private boolean booked;
    @Enumerated(EnumType.STRING)
    private RoomType roomType;
    @ManyToOne
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;
    @OneToOne(mappedBy = "hotelPackage")
    private HotelBooking hotelBooking;
}
