package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.response.client.ClientResponseDTO;
import com.globant.finalchallenge.tourismagency.service.contract.IApiUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Pattern;

@RestController
@RequestMapping("clients")
public class ApiUserController {

    private final IApiUserService apiUserService;

    public ApiUserController(IApiUserService apiUserService) {
        this.apiUserService = apiUserService;
    }

    @GetMapping("top-3")
    public ResponseEntity<ClientResponseDTO> getTopThree(@RequestParam @Pattern(regexp = "[0-9]{4}$",message = "The year must have four digits") String year){
        return ResponseEntity.ok()
                .body(this.apiUserService.getTopThree(Integer.parseInt(year)));
    }
}
