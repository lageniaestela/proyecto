package com.globant.finalchallenge.tourismagency.util.deserialization;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.globant.finalchallenge.tourismagency.error_handling.exception.InvalidIntegerFormatInFieldException;
import com.globant.finalchallenge.tourismagency.util.DeserializationUtils;

import java.io.IOException;

public class ValidatedIntegerDeserializer extends JsonDeserializer<Integer> {

    @Override
    public Integer deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        try {
            Integer result = Integer.parseInt(jsonParser.getText());
            System.out.println("Integer deserialization from " + jsonParser.getText() + " yielded " + result);
            return result;
        } catch (NumberFormatException e) {
            throw new InvalidIntegerFormatInFieldException(
                    jsonParser.getText(),
                    DeserializationUtils.getFullFieldJsonPathStr(jsonParser)
            );
        }
    }
}
