package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.PersonDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Person;
import com.globant.finalchallenge.tourismagency.repository.IPersonRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IPersonService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class PersonServiceImpl implements IPersonService {
    private final IPersonRepository personRepository;
    private final ModelMapper modelMapper;

    public PersonServiceImpl(IPersonRepository personRepository, ModelMapper modelMapper) {
        this.personRepository = personRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public PersonDTO findById(Long id) {
        Optional<Person> result = personRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("Person", id.toString());

        return modelMapper.map(result.get(), PersonDTO.class);
    }

    @Override
    public List<PersonDTO> findAll() {
        List<Person> persons = personRepository.findAll();

        if (persons.isEmpty())
            throw new NoItemsMatchQueryException("persons");

        return persons.stream()
                .map(person -> modelMapper.map(person, PersonDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(PersonDTO personDTO) {
        Person person = modelMapper.map(personDTO, Person.class);
        person = personRepository.save(person);
        return GlobalHelper.createResponse(
                "Person",
                person.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, PersonDTO personDTO) {
        Person person = modelMapper.map(personDTO, Person.class);
        person.setId(id);

        if (!personRepository.existsById(id))
            throw new ItemNotFoundException("person", id.toString());

        person = personRepository.save(person);
        return GlobalHelper.createResponse(
                "Person",
                person.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<Person> person = personRepository.findById(id);

        if (person.isEmpty())
            throw new ItemNotFoundException("person", id.toString());

        personRepository.deleteById(person.get().getId());
        return GlobalHelper.createResponse(
                "Person",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    public List<Person> conditionallyPersistPeople(List<PersonDTO> peopleDTOList) {
        List<Person> allPeople = personRepository.findAll();

        List<Person> peopleToPersist = new ArrayList<>();
        List<Person> matchingPeople = new ArrayList<>();

        for (PersonDTO personDTO: peopleDTOList) {
            Person persistedPerson = null;
            for (Person person : allPeople) {
                if ( person.getDni().equals(personDTO.getDni()) ) {
                    persistedPerson = person;
                    break;
                }
            }
            if (persistedPerson != null) {
                matchingPeople.add(persistedPerson);
            } else {
                Person personToPersist = modelMapper.map(personDTO, Person.class);
                peopleToPersist.add(personRepository.save(personToPersist));
            }
        }

        List<Person> persistedPeople = personRepository.saveAll(peopleToPersist);
        return Stream.concat(persistedPeople.stream(), matchingPeople.stream())
                .collect(Collectors.toList());
    }
}
