package com.globant.finalchallenge.tourismagency.util;

import com.globant.finalchallenge.tourismagency.util.payments.InterestTier;

import java.math.BigDecimal;
import java.util.Set;

import static com.globant.finalchallenge.tourismagency.enumerator.PaymentType.*;

public abstract class GlobalConstants {
    public static final Set<InterestTier> INTEREST_TIERS = Set.of(
            new InterestTier(1,1, BigDecimal.ZERO, Set.of(CREDIT, DEBIT)),
            new InterestTier(2,3, new BigDecimal("0.05"), Set.of(CREDIT)),
            new InterestTier(4,6, new BigDecimal("0.10"), Set.of(CREDIT)),
            new InterestTier(7, 12, new BigDecimal("0.15"), Set.of(CREDIT))
    );
}
