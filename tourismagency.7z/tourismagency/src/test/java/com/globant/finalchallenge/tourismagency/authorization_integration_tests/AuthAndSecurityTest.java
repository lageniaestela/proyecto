package com.globant.finalchallenge.tourismagency.authorization_integration_tests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.PaymentMethodDTO;
import com.globant.finalchallenge.tourismagency.dto.PersonDTO;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.FlightReservationDTORequest;
import com.globant.finalchallenge.tourismagency.dto.request.flight_reservation.ReservationDTORequest;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.BookingDTORequest;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.HotelBookingDTORequest;
import com.globant.finalchallenge.tourismagency.enumerator.RoomType;
import com.globant.finalchallenge.tourismagency.enumerator.SeatType;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.security.SecurityConstants;
import com.globant.finalchallenge.tourismagency.test_utils.*;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
// ATTENTION: There is no need to include server.servlet.context-path in the paths to test.
class AuthAndSecurityTest {
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private MockMvc mockMvc;

    private final String userLogin = "{ \"username\": \"user1@mail.com\", \"password\": \"Password123\" }";
    private final String employeeLogin = "{ \"username\": \"user5@mail.com\", \"password\": \"Password123\" }";

    @Test
    void testUserCreationAndLogin_isSuccessful() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/users/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"username\": \"acevedosharp\", \"password\": \"Password123\" }"))
                .andExpect(status().is(200))
                .andReturn();

        mockMvc.perform(MockMvcRequestBuilders.post("/users/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"username\": \"acevedosharp\", \"password\": \"Password123\" }"))
                .andExpect(status().is(200))
                .andExpect(header().exists("Authorization"));
    }

    @Test
    void testAuthentication_allCrudRequiresAuthentication_areForbidden() throws Exception {
        Hotel hotel = HotelProvider.generateHotel(1);
        hotel.setHotelCode("AF-2718");

        HotelPackageDTO hotelPackage = modelMapper.map(HotelPackageProvider.generatePackage(1), HotelPackageDTO.class);
        hotelPackage.setHotelCode("AF-2718");

        FlightReservationDTORequest flightReservationDTORequest = new FlightReservationDTORequest(
                "user1@mail.com",
                new ReservationDTORequest(
                        LocalDate.now(),
                        LocalDate.now(),
                        "Bogota",
                        "Seattle",
                        "ABCD-2718",
                        10,
                        SeatType.ECONOMY,
                        List.of(modelMapper.map(PersonProvider.generatePerson(1), PersonDTO.class)),
                        modelMapper.map(PaymentMethodProvider.generatePaymentMethod(), PaymentMethodDTO.class)
                )
        );

        HotelBookingDTORequest hotelBookingDTORequest = new HotelBookingDTORequest(
                "sharp.acevedo@gmail.com",
                new BookingDTORequest(
                        LocalDate.now(),
                        LocalDate.now(),
                        "Seattle",
                        "SE-2718",
                        10,
                        RoomType.SINGLE,
                        List.of(modelMapper.map(PersonProvider.generatePerson(1), PersonDTO.class)),
                        modelMapper.map(PaymentMethodProvider.generatePaymentMethod(), PaymentMethodDTO.class)
                )
        );



        Map<String, Object> routes = Map.of(
                "/flights", FlightProvider.findById(1L),
                "/flight-packages", FlightPackageDTOProvider.generateOneRandom(),
                "/flight-reservations", flightReservationDTORequest,
                "/hotels", hotel,
                "/hotel-packages", hotelPackage,
                "/hotel-bookings", hotelBookingDTORequest
        );

        ObjectMapper objectMapper = new ObjectMapper();

        for (Map.Entry<String, Object> entry : routes.entrySet()) {
            mockMvc.perform(MockMvcRequestBuilders.get(entry.getKey()))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.post(entry.getKey())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.put(entry.getKey() + "/1")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.delete(entry.getKey() + "/1"))
                    .andExpect(status().is(403));
        }
    }

    @Test
    void testAuthentication_employeeMethods_employeeSucceeds() throws Exception {
        String bearerToken = getToken(employeeLogin);

        List<String> routes = List.of(
                "/flights",
                "/flight-packages",
                "/flight-reservations",
                "/hotels",
                "/hotel-packages",
                "/hotel-bookings"
        );

        for (String route : routes) {
            int status = mockMvc.perform(MockMvcRequestBuilders.get(route)
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);

            status = mockMvc.perform(MockMvcRequestBuilders.post(route)
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);

            status = mockMvc.perform(MockMvcRequestBuilders.put(route)
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);

            status = mockMvc.perform(MockMvcRequestBuilders.delete(route)
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);
        }
    }

    @Test
    void testAuthentication_employeeMethods_userFails() throws Exception {
        String bearerToken = getToken(userLogin);

        Hotel hotel = HotelProvider.generateHotel(1);
        hotel.setHotelCode("AF-2718");

        HotelPackageDTO hotelPackage = modelMapper.map(HotelPackageProvider.generatePackage(1), HotelPackageDTO.class);
        hotelPackage.setHotelCode("AF-2718");

        Map<String, Object> routesAllowOnlyEmployee = Map.of(
                "/flights", FlightProvider.findById(1L),
                "/flight-packages", FlightPackageDTOProvider.generateOneRandom(),
                "/hotels", hotel,
                "/hotel-packages", hotelPackage
        );

        Map<String, Object> routesAllowUserForPost = Map.of(
                "/flight-reservations", FlightReservationProvider.generateFlightReservation(1),
                "/hotel-bookings", HotelBookingProvider.generateHotelBooking(1L)
        );

        ObjectMapper objectMapper = new ObjectMapper();

        for (Map.Entry<String, Object> entry : routesAllowOnlyEmployee.entrySet()) {
            mockMvc.perform(MockMvcRequestBuilders.get(entry.getKey())
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.post(entry.getKey())
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.put(entry.getKey() + "/1")
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.delete(entry.getKey() + "/1")
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                    .andExpect(status().is(403));
        }

        for (Map.Entry<String, Object> entry : routesAllowUserForPost.entrySet()) {
            mockMvc.perform(MockMvcRequestBuilders.get(entry.getKey())
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));

            mockMvc.perform(MockMvcRequestBuilders.delete(entry.getKey() + "/1")
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andExpect(status().is(403));
        }
    }

    @Test
    void testAuthentication_userMethods_userSucceeds() throws Exception {
        String bearerToken = getToken(userLogin);

        Map<String, Object> routesAllowUserForPost = Map.of(
                "/flight-reservations", FlightReservationProvider.generateFlightReservation(1),
                "/hotel-bookings", HotelBookingProvider.generateHotelBooking(1L)
        );

        ObjectMapper objectMapper = new ObjectMapper();

        for (Map.Entry<String, Object> entry : routesAllowUserForPost.entrySet()) {
            int status = mockMvc.perform(MockMvcRequestBuilders.post(entry.getKey())
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);

            status = mockMvc.perform(MockMvcRequestBuilders.put(entry.getKey() + "/1")
                            .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(entry.getValue())))
                    .andReturn()
                    .getResponse().getStatus();
            assertNotEquals(403, status);
        }
    }

    @Test
    void testAuthentication_incomeForEmployees_employeeSucceeds() throws Exception {
        String bearerToken = getToken(employeeLogin);

        mockMvc.perform(MockMvcRequestBuilders.get("/income?month=12&year=2021")
                        .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                .andExpect(status().is(200));
    }

    @Test
    void testAuthentication_incomeForEmployees_userFails() throws Exception {
        String bearerToken = getToken(userLogin);

        mockMvc.perform(MockMvcRequestBuilders.get("/income?month=12&year=2021")
                        .header(SecurityConstants.HEADER_AUTHORIZARION_KEY, bearerToken))
                .andExpect(status().is(403));
    }

    private String getToken(String loginData) throws Exception {
        return mockMvc.perform(MockMvcRequestBuilders.post("/users/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginData))
                .andExpect(status().is(200))
                .andReturn()
                .getResponse()
                .getHeader(SecurityConstants.HEADER_AUTHORIZARION_KEY);
    }
}
