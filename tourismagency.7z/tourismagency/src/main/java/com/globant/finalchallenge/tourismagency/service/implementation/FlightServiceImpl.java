package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.repository.IFlightRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightService;
import com.globant.finalchallenge.tourismagency.util.DateUtil;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FlightServiceImpl implements IFlightService {
    private final IFlightRepository flightRepository;
    private final ModelMapper modelMapper;

    public FlightServiceImpl(IFlightRepository flightRepository, ModelMapper modelMapper) {
        this.flightRepository = flightRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public FlightDTO findById(Long id) {
        Optional<Flight> result = flightRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("Flight", id.toString());

        return modelMapper.map(result.get(), FlightDTO.class);
    }

    @Override
    public List<FlightDTO> findAll() {
        List<Flight> flights = flightRepository.findAll();

        if (flights.isEmpty())
            throw new NoItemsMatchQueryException("flights");

        return flights.stream()
                .map(flight -> modelMapper.map(flight, FlightDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(FlightDTO flightDTO) {
        DateUtil.validateDates(flightDTO.getDeparture(), flightDTO.getArrival());

        Flight flight = modelMapper.map(flightDTO, Flight.class);
        flight = flightRepository.save(flight);
        return GlobalHelper.createResponse(
                "Flight",
                flight.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, FlightDTO flightDTO) {
        Flight flight = modelMapper.map(flightDTO, Flight.class);
        flight.setId(id);

        if (!flightRepository.existsById(id))
            throw new ItemNotFoundException("flight", id.toString());

        flight = flightRepository.save(flight);
        return GlobalHelper.createResponse(
                "Flight",
                flight.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<Flight> flight = flightRepository.findById(id);

        if (flight.isEmpty())
            throw new ItemNotFoundException("flight", id.toString());

        flightRepository.deleteById(flight.get().getId());
        return GlobalHelper.createResponse(
                "Flight",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }
}
