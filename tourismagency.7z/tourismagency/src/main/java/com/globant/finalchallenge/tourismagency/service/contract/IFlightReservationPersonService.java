package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.FlightReservationPersonDTO;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.FlightReservationPerson;
import com.globant.finalchallenge.tourismagency.model.Person;
import org.springframework.stereotype.Service;

import java.util.List;

public interface IFlightReservationPersonService extends ICRUD<FlightReservationPersonDTO, FlightReservationPersonDTO> {
    List<FlightReservationPerson> createFlightReservationPeople(List<Person> people, FlightReservation flightReservation);
}
