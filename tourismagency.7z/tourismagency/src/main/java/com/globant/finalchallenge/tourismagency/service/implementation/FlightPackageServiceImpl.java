package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.flight.BodyFlightPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.flight.FlightPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.*;
import com.globant.finalchallenge.tourismagency.model.*;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.repository.IFlightPackageRepository;
import com.globant.finalchallenge.tourismagency.repository.IFlightRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightPackageFlightService;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightPackageService;
import com.globant.finalchallenge.tourismagency.util.AuxMapper;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.criteria.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FlightPackageServiceImpl implements IFlightPackageService {
    private final IFlightRepository flightRepository;
    private final IFlightPackageRepository flightPackageRepository;
    private final IFlightPackageFlightService flightPackageFlightService;
    private final ModelMapper modelMapper;
    private final EntityManager entityManager;


    public FlightPackageServiceImpl(IFlightRepository flightRepository, IFlightPackageRepository flightPackageRepository, IFlightPackageFlightService flightPackageFlightService, ModelMapper modelMapper,EntityManager entityManager) {
        this.flightRepository = flightRepository;
        this.flightPackageRepository = flightPackageRepository;
        this.flightPackageFlightService = flightPackageFlightService;
        this.modelMapper = modelMapper;
        this.entityManager = entityManager;
    }

    @Override
    public FlightPackageDTO findById(Long id) {
        Optional<FlightPackage> result = flightPackageRepository.findById(id);

        if (result.isEmpty()) {
            throw new ItemNotFoundException("FlightPackage", id.toString());
        }

        return flightPackageDTOWithFlights(result.get());
    }

    private FlightPackageDTO flightPackageDTOWithFlights(FlightPackage flightPackage){
        FlightPackageDTO flightPackageDTO = modelMapper.map(flightPackage, FlightPackageDTO.class);

        flightPackageDTO.setFlights(flightPackage.getFlightPackageFlights()
                .stream()
                .map(e -> AuxMapper.map(
                        flightRepository.findById(
                                e.getFlight().getId())
                                .get()))
                .collect(Collectors.toList()));

        return flightPackageDTO;
    }

    @Override
    public List<FlightPackageDTO> findAll() {
        List<FlightPackage> flightPackages = flightPackageRepository.findAll();

        if (flightPackages.isEmpty())
            throw new NoItemsMatchQueryException("flightPackages");

        return flightPackages.stream()
                .map(this::flightPackageDTOWithFlights)
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(FlightPackageDTO flightPackageDTO) {
        FlightPackage flightPackage = AuxMapper.map(flightPackageDTO);
        flightPackage = getFlightPackage(flightPackageDTO, flightPackage);

        return GlobalHelper.createResponse(
                "FlightPackage",
                flightPackage.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, FlightPackageDTO flightPackageDTO) {


        FlightPackage flightPackageOld = flightPackageRepository.findById(id).orElseThrow(()->new ItemNotFoundException(FlightPackage.class.getName(), id.toString()));
        if(flightPackageOld.isReserved()) {
            throw new PackageCannotBeEditedOrDeletedException(id, "edited");
        }

        FlightPackage flightPackage = AuxMapper.map(flightPackageDTO);
        flightPackage.setId(flightPackageOld.getId());
        flightPackage = getFlightPackage(flightPackageDTO, flightPackage);

        return GlobalHelper.createResponse(
                "FlightPackage",
                flightPackage.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    private FlightPackage getFlightPackage(FlightPackageDTO flightPackageDTO, FlightPackage flightPackage) {
        flightPackage = flightPackageRepository.save(flightPackage);

        FlightPackage finalFlightPackage = flightPackage;
        List<FlightPackageFlight> flightList = flightPackageDTO.getFlights()
                .stream()
                .map(
                        flightDTO -> flightPackageFlightService
                                .createFlightPackageFlightFromFlightDTO(finalFlightPackage, flightDTO))
                .collect(Collectors.toList());

        flightPackage.setFlightPackageFlights(flightList);

        flightPackageRepository.save(flightPackage);
        return flightPackage;
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {

        FlightPackage flightPackage = flightPackageRepository.findById(id).orElseThrow(() -> new ItemNotFoundException(FlightPackage.class.getName(), id.toString()));
        if (flightPackage.isReserved()) {
            throw new PackageCannotBeEditedOrDeletedException(id, "deleted");
        }

        flightPackageRepository.deleteById(id);
        return GlobalHelper.createResponse(
                "FlightPackage",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public Optional<FlightPackage> findByFlightPackageNumber(String flightNumber) {
        return this.flightPackageRepository.findByFlightPackageNumber(flightNumber);
    }

    @Override
    public FlightPackage save(FlightPackage flightPackage) {
        return flightPackageRepository.save(flightPackage);
    }

    @Override
    public FlightPackageResponseDTO getAllByFilter(Optional<String> dateFrom, Optional<String> dateTo,Optional<String> origin, Optional<String> destination) {
        FlightPackageResponseDTO responseDTO = new FlightPackageResponseDTO();
        List<Predicate> predicates = new ArrayList<>();

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FlightPackage> criteria = criteriaBuilder.createQuery(FlightPackage.class);
        Root<FlightPackage> root = criteria.from(FlightPackage.class);
        if (destination.isPresent()) {
            responseDTO.setDestination(destination.get());
            Predicate predicate = criteriaBuilder.like(root.<String>get("destination"), destination.get());
            predicates.add(predicate);
        }
        if (origin.isPresent()) {
            responseDTO.setOrigin(origin.get());
            Predicate predicate = criteriaBuilder.like(root.<String>get("origin"), origin.get());
            predicates.add(predicate);
        }
        if (dateFrom.isPresent()) {
            LocalDate localDateFrom = GlobalHelper.parseLocalDateFromStringWithOptions(dateFrom.get(), "dateFrom", true);
            responseDTO.setDateFrom(localDateFrom);
            Predicate predicate = criteriaBuilder.greaterThanOrEqualTo(root.<LocalDate>get("dateFrom"), localDateFrom);
            predicates.add(predicate);
        }
        if (dateTo.isPresent()) {
            LocalDate localDateTo = GlobalHelper.parseLocalDateFromStringWithOptions(dateTo.get(), "dateTo", true);
            responseDTO.setDateTo(localDateTo);
            Predicate predicate = criteriaBuilder.lessThanOrEqualTo(root.<LocalDate>get("dateTo"), localDateTo);
            predicates.add(predicate);
        }
        criteria.select(root);
        criteria.where(criteriaBuilder.and(predicates.toArray(new Predicate[0])));
        List<FlightPackage> flightPackage = entityManager.createQuery(criteria).getResultList();
        this.fillDTOFlightPackageResponse(responseDTO, flightPackage);
        return responseDTO;
    }

    private FlightPackageResponseDTO fillDTOFlightPackageResponse(FlightPackageResponseDTO responseDTO, List<FlightPackage> flightPackages) {
        List<BodyFlightPackageResponseDTO> bodies = new ArrayList<>();
        flightPackages.forEach(flightPackage -> {
            BodyFlightPackageResponseDTO body = new BodyFlightPackageResponseDTO();
            body.setFlightNumber(flightPackage.getFlightPackageNumber());
            body.setOrigin(flightPackage.getOrigin());
            body.setDestination(flightPackage.getDestination());
            body.setSeatType(flightPackage.getSeatType());
            body.setFlightPrice(flightPackage.getPrice());
            body.setGoingDate(flightPackage.getDateFrom());
            body.setReturnDate(flightPackage.getDateTo());
            bodies.add(body);
        });
        responseDTO.setFlights(bodies);
        return responseDTO;
    }
}
