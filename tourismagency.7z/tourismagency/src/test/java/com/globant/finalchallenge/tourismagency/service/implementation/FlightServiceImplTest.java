package com.globant.finalchallenge.tourismagency.service.implementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.LocalDateFromIsAfterToException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.repository.IFlightRepository;
import com.globant.finalchallenge.tourismagency.test_utils.FlightProvider;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;


class FlightServiceImplTest {

    @Mock
    private IFlightRepository flightRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private FlightServiceImpl flightService;

    private List<Flight> flightsList;
    private List<FlightDTO> flightDTOList;
    private Flight simpleFlight;
    private FlightDTO simpleFlightDTO;
    private FlightDTO invalidDateFlightDTO;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
        flightsList = FlightProvider.findAll();
        flightDTOList = FlightProvider.findAllDTO();
        simpleFlight = FlightProvider.findById(1L);
        simpleFlightDTO = FlightProvider.findByIdDTO(1L);
        invalidDateFlightDTO = FlightProvider.invalidDatesFlightDTO();
    }

    // findAll
    @Test
    void whenFindAllThenSuccess() {
        when(flightRepository.findAll()).thenReturn(flightsList);
        IntStream.range(0, flightsList.size())
                .forEach(i -> when(modelMapper.map(flightsList.get(i), FlightDTO.class))
                        .thenReturn(flightDTOList.get(i)));

        assertEquals(flightDTOList, flightService.findAll());
    }
    @Test
    void whenFindAllThenThrowNoItemsMatchQueryException(){
        when(flightRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, () -> flightService.findAll());
        verify(flightRepository, atLeastOnce()).findAll();
    }

    // findById
    @Test
    void whenFindByIdThenSuccess() {
        FlightDTO expectedResult = simpleFlightDTO;

        when(flightRepository.findById(simpleFlight.getId())).
                thenReturn(Optional.of(simpleFlight));
        when(modelMapper.map(Optional.of(simpleFlight).get(), FlightDTO.class)).
                thenReturn(simpleFlightDTO);

        FlightDTO result = flightService.findById(simpleFlight.getId());

        verify(flightRepository, atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());
        assertEquals(expectedResult, result);
    }
    @Test
    void whenFindByIdThenThrowItemNotFoundException(){
        when(flightRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> flightService.findById(1L));
        verify(flightRepository, atLeastOnce()).findById(1L);
    }

    // save
    @Test
    void whenSaveThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Flight",
                simpleFlight.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(simpleFlightDTO, Flight.class)).thenReturn(simpleFlight);
        when(flightRepository.save(simpleFlight)).thenReturn(simpleFlight);

        SimpleCRUDResponseDTO result = flightService.save(simpleFlightDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightRepository, atLeastOnce()).save(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }
    @Test
    void whenSaveThrowInvalidDatesException(){
        assertThrows(LocalDateFromIsAfterToException.class, () -> flightService.save(invalidDateFlightDTO));
    }

    // delete
    @Test
    void whenDeleteThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Flight",
                simpleFlight.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(flightRepository.findById(simpleFlight.getId())).thenReturn(Optional.of(simpleFlight));
        doNothing().when(flightRepository).deleteById(simpleFlight.getId());

        SimpleCRUDResponseDTO result = flightService.delete(simpleFlight.getId());

        verify(flightRepository, atLeastOnce()).findById(any());
        verify(flightRepository, atLeastOnce()).deleteById(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }
    @Test
    void whenDeleteThrowItemNotFoundException(){
        when(flightRepository.findById(simpleFlight.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> flightService.delete(simpleFlight.getId()));
        verify(flightRepository, atLeastOnce()).findById(any());
    }

    // update
    @Test
    void whenUpdateThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Flight",
                simpleFlight.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(simpleFlightDTO, Flight.class)).thenReturn(simpleFlight);
        when(flightRepository.existsById(simpleFlightDTO.getId())).thenReturn(true);
        when(flightRepository.save(simpleFlight)).thenReturn(simpleFlight);

        SimpleCRUDResponseDTO result = flightService.update(simpleFlightDTO.getId(), simpleFlightDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightRepository, atLeastOnce()).existsById(any());
        verify(flightRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }
    @Test
    void updateShouldReturnItemNotFoundException() {
        when(modelMapper.map(simpleFlightDTO, Flight.class)).thenReturn(simpleFlight);
        when(flightRepository.existsById(simpleFlight.getId())).thenReturn(false);

        assertThrows(ItemNotFoundException.class, () -> flightService.update(1L, simpleFlightDTO));
        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightRepository, atLeastOnce()).existsById(any());
    }

}
