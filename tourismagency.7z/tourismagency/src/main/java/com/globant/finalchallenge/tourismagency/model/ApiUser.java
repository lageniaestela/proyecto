package com.globant.finalchallenge.tourismagency.model;

import com.globant.finalchallenge.tourismagency.enumerator.RoleType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "api_users")
public class ApiUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userName;
    private String password;
    @Enumerated(EnumType.STRING)
    private RoleType roleType;
    @OneToMany(mappedBy = "apiUser")
    private List<HotelBooking> hotelBookings;
    @OneToMany(mappedBy = "apiUser")
    private List<FlightReservation> flightReservations;
    @OneToOne
    @JoinColumn(name = "person_id")
    private Person person;
}
