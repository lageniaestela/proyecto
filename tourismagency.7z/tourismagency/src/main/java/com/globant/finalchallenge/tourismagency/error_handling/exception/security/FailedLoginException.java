package com.globant.finalchallenge.tourismagency.error_handling.exception.security;

public class FailedLoginException extends RuntimeException {
    public FailedLoginException() {
        super("Login error. Check your username and password");
    }
}
