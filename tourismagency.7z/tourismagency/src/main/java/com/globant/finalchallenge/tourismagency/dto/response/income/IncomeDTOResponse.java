package com.globant.finalchallenge.tourismagency.dto.response.income;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IncomeDTOResponse {
        @JsonProperty("total_income_hotelBooking")
        private Double totalIncomeHotelBooking;
        @JsonProperty("total_income_flightReservation")
        private Double totalIncomeFlightReservation;
}
