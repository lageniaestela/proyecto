package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;

import java.time.LocalDate;

public abstract class FlightReservationProvider {
    public static FlightReservation generateFlightReservation(Integer number){
        return new FlightReservation(
                number.longValue(),
                LocalDate.of(2021, 7, 27),
                null,
                null,
                null,
                null
        );
    }
}
