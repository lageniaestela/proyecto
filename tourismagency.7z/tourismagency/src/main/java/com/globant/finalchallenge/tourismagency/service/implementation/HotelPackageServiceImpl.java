package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.PackageCannotBeEditedOrDeletedException;
import com.globant.finalchallenge.tourismagency.dto.response.hotel.BodyHotelPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.hotel.HotelPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.HotelWithCodeNotExists;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;
import com.globant.finalchallenge.tourismagency.repository.IHotelPackageRepository;
import com.globant.finalchallenge.tourismagency.repository.IHotelRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelPackageService;
import com.globant.finalchallenge.tourismagency.util.AuxMapper;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HotelPackageServiceImpl implements IHotelPackageService {
    private final IHotelRepository hotelRepository;
    private final IHotelPackageRepository hotelPackageRepository;
    private final ModelMapper modelMapper;
    private final EntityManager entityManager;

    public HotelPackageServiceImpl(IHotelPackageRepository hotelPackageRepository, IHotelRepository hotelRepository, ModelMapper modelMapper, EntityManager entityManager) {
        this.hotelRepository = hotelRepository;
        this.hotelPackageRepository = hotelPackageRepository;
        this.modelMapper = modelMapper;
        this.entityManager = entityManager;
    }


    @Override
    public HotelPackageDTO findById(Long id) {
        Optional<HotelPackage> result = hotelPackageRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("HotelPackage", id.toString());

        return modelMapper.map(result.get(), HotelPackageDTO.class);
    }

    @Override
    public List<HotelPackageDTO> findAll() {
        List<HotelPackage> hotelPackages = hotelPackageRepository.findAll();

        if (hotelPackages.isEmpty())
            throw new NoItemsMatchQueryException("hotelPackages");

        return hotelPackages.stream()
                .map(hotelPackage -> modelMapper.map(hotelPackage, HotelPackageDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(HotelPackageDTO hotelPackageDTO) {

        String codeHotel = hotelPackageDTO.getHotelCode();
        hotelPackageDTO.setId(null);
        HotelPackage hotelPackage = AuxMapper.map(hotelPackageDTO);
        hotelPackage.setBooked(false);

        Hotel hotel = hotelRepository.findByHotelCode(codeHotel).orElseThrow(() -> new HotelWithCodeNotExists(codeHotel));
        hotelPackage.setHotel(hotel);
        hotelPackage = hotelPackageRepository.save(hotelPackage);
        return GlobalHelper.createResponse(
                "HotelPackage",
                hotelPackage.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, HotelPackageDTO hotelPackageDTO) {

        HotelPackage hotelPackageOld = hotelPackageRepository.findById(id).orElseThrow(()->new ItemNotFoundException(HotelPackage.class.getName(), id.toString()));
        if(hotelPackageOld.isBooked())
            throw new PackageCannotBeEditedOrDeletedException(id,"edited");


        HotelPackage hotelPackageNew = AuxMapper.map(hotelPackageDTO);

        String codeHotel = hotelPackageDTO.getHotelCode();
        Hotel hotel = hotelRepository.findByHotelCode(codeHotel).orElseThrow(()->new HotelWithCodeNotExists(codeHotel));


        hotelPackageNew.setId(id);
        hotelPackageNew.setHotel(hotel);

        hotelPackageNew = hotelPackageRepository.save(hotelPackageNew);
        return GlobalHelper.createResponse(
                "HotelPackage",
                hotelPackageNew.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {


        HotelPackage hotelPackage = hotelPackageRepository.findById(id).orElseThrow(()->new ItemNotFoundException(HotelPackage.class.getName(), id.toString()));
        if(hotelPackage.isBooked())
            throw new PackageCannotBeEditedOrDeletedException(id,"deleted");


        hotelPackageRepository.deleteById(id);
        return GlobalHelper.createResponse(
                "HotelPackage",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public HotelPackage save(HotelPackage hotelPackage) {
        return hotelPackageRepository.save(hotelPackage);
    }

    @Override
    public HotelPackageResponseDTO getAllByFilter(Optional<String> dateFrom, Optional<String> dateTo, Optional<String> destination) {
        List<Predicate> predicates = new ArrayList<>();

        HotelPackageResponseDTO responseDTO = new HotelPackageResponseDTO();

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<HotelPackage> criteria = criteriaBuilder.createQuery(HotelPackage.class);
        Root<HotelPackage> root = criteria.from(HotelPackage.class);
        if (destination.isPresent()) {
            responseDTO.setDestination(destination.get());
            Predicate predicate = criteriaBuilder.like(root.<String>get("hotel").get("place"), destination.get());
            predicates.add(predicate);
        }
        if (dateFrom.isPresent()) {
            LocalDate localDateFrom = GlobalHelper.parseLocalDateFromStringWithOptions(dateFrom.get(), "dateFrom", true);
            responseDTO.setDateFrom(localDateFrom);
            Predicate predicate = criteriaBuilder.greaterThanOrEqualTo(root.<LocalDate>get("dateFrom"), localDateFrom);
            predicates.add(predicate);
        }
        if (dateTo.isPresent()) {
            LocalDate localDateTo = GlobalHelper.parseLocalDateFromStringWithOptions(dateTo.get(), "dateTo", true);
            responseDTO.setDateTo(localDateTo);
            Predicate predicate = criteriaBuilder.lessThanOrEqualTo(root.<LocalDate>get("dateTo"), localDateTo);
            predicates.add(predicate);
        }
        criteria.select(root);
        criteria.where(criteriaBuilder.and(predicates.toArray(new Predicate[0])));
        List<HotelPackage> hotelPackages = entityManager.createQuery(criteria).getResultList();
        this.fillDTOHotelPackageResponse(responseDTO, hotelPackages);
        return responseDTO;
    }

    private HotelPackageResponseDTO fillDTOHotelPackageResponse(HotelPackageResponseDTO responseDTO, List<HotelPackage> hotelPackages) {
        List<BodyHotelPackageResponseDTO> bodies = new ArrayList<>();
        hotelPackages.forEach(hotelPackage -> {
            BodyHotelPackageResponseDTO body = new BodyHotelPackageResponseDTO();
            body.setHotelCode(hotelPackage.getHotel().getHotelCode());
            body.setPlace(hotelPackage.getHotel().getPlace());
            body.setName(hotelPackage.getHotel().getHotelName());
            body.setRoomType(hotelPackage.getRoomType());
            body.setRoomPrice(hotelPackage.getRoomPrice());
            body.setDisponibilityDateFrom(hotelPackage.getDateFrom());
            body.setDisponibilityDateTo(hotelPackage.getDateTo());
            body.setBooking(hotelPackage.isBooked());
            bodies.add(body);
        });
        responseDTO.setHotels(bodies);
        return responseDTO;
    }


}
