package com.globant.finalchallenge.tourismagency.util.payments;

import com.globant.finalchallenge.tourismagency.dto.PaymentMethodDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.DuesNotSupportedForPaymentTypeException;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;
import com.globant.finalchallenge.tourismagency.model.Payment;
import com.globant.finalchallenge.tourismagency.util.DateUtil;
import com.globant.finalchallenge.tourismagency.util.GlobalConstants;

import java.math.BigDecimal;
import java.util.Optional;

public abstract class PaymentCalculator {
    public static SimplePaymentRepresentation calculateHotelPayment(HotelPackage hotelPackage, PaymentMethodDTO paymentMethodDTO) {
        long nDays = DateUtil.daysDifference(hotelPackage.getDateFrom(), hotelPackage.getDateTo());
        BigDecimal rawTotal = hotelPackage.getRoomPrice().multiply(BigDecimal.valueOf(nDays));

        return calculatePayment(rawTotal, paymentMethodDTO);
    }

    public static SimplePaymentRepresentation calculateFlightPayment(FlightPackage flightPackage, PaymentMethodDTO paymentMethodDTO){
        BigDecimal rawTotal = flightPackage.getPrice();

        return calculatePayment(rawTotal, paymentMethodDTO);
    }

    private static SimplePaymentRepresentation calculatePayment(BigDecimal rawTotal, PaymentMethodDTO paymentMethodDTO){
        Optional<InterestTier> matchingTier = GlobalConstants.INTEREST_TIERS.stream()
                .filter(iTier ->
                        iTier.getDuesFrom() <= paymentMethodDTO.getDues() &&
                                paymentMethodDTO.getDues() <= iTier.getDuesTo()
                )
                .findFirst();

        validatePaymentType(matchingTier, paymentMethodDTO);

        BigDecimal interestRate = matchingTier.get().getInterestRate();

        BigDecimal withInterest = rawTotal.multiply(
                BigDecimal.ONE.add(interestRate)
        );

        return new SimplePaymentRepresentation(
                withInterest, rawTotal, interestRate.doubleValue()
        );
    }

    private static void validatePaymentType (Optional<InterestTier> matchingTier, PaymentMethodDTO paymentMethodDTO){
        if (matchingTier.isEmpty() || !matchingTier.get().getSupportedPaymentMethods().contains(paymentMethodDTO.getPaymentType()))
            throw new DuesNotSupportedForPaymentTypeException(paymentMethodDTO.getDues(), paymentMethodDTO.getPaymentType());
    }


}
