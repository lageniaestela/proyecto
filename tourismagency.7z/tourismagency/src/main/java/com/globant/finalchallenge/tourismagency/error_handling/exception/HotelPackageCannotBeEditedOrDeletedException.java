package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class HotelPackageCannotBeEditedOrDeletedException extends RuntimeException {
    public HotelPackageCannotBeEditedOrDeletedException(Long id, String editedOrDeleted) {
        super(String.format(
                "Hotel package with id %s cannot be %s because it's booked",
                id,
                editedOrDeleted
        ));
    }
}
