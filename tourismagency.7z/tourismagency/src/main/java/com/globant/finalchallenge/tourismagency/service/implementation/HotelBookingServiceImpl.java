package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelBookingDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.BookingDTORequest;
import com.globant.finalchallenge.tourismagency.dto.request.hotel_booking.HotelBookingDTORequest;
import com.globant.finalchallenge.tourismagency.error_handling.exception.*;
import com.globant.finalchallenge.tourismagency.model.*;
import com.globant.finalchallenge.tourismagency.repository.IHotelBookingRepository;
import com.globant.finalchallenge.tourismagency.service.contract.*;
import com.globant.finalchallenge.tourismagency.util.DateUtil;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import com.globant.finalchallenge.tourismagency.util.payments.PaymentCalculator;
import com.globant.finalchallenge.tourismagency.util.payments.SimplePaymentRepresentation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HotelBookingServiceImpl implements IHotelBookingService {

    private final IHotelBookingRepository hotelBookingRepository;
    private final IHotelService hotelService;
    private final IPersonService personService;
    private final IApiUserService apiUserService;

    private final IPaymentMethodService paymentMethodService;
    private final IPaymentService paymentService;

    private final IHotelBookingPersonService hotelBookingPersonService;
    private final IHotelPackageService hotelPackageService;

    private final ModelMapper modelMapper;

    public HotelBookingServiceImpl(IHotelBookingRepository hotelBookingRepository, IHotelService hotelService, IPersonService personService, IApiUserService apiUserService, IPaymentMethodService paymentMethodService, IPaymentService paymentService, IHotelBookingPersonService hotelBookingPersonService, IHotelPackageService hotelPackageService, ModelMapper modelMapper) {
        this.hotelBookingRepository = hotelBookingRepository;
        this.hotelService = hotelService;
        this.personService = personService;
        this.apiUserService = apiUserService;
        this.paymentMethodService = paymentMethodService;
        this.paymentService = paymentService;
        this.hotelBookingPersonService = hotelBookingPersonService;
        this.hotelPackageService = hotelPackageService;
        this.modelMapper = modelMapper;
    }


    @Override
    public HotelBookingDTO findById(Long id) {
        Optional<HotelBooking> result = hotelBookingRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("HotelBooking", id.toString());

        return modelMapper.map(result.get(), HotelBookingDTO.class);
    }

    @Override
    public List<HotelBookingDTO> findAll() {
        List<HotelBooking> hotels = hotelBookingRepository.findAll();

        if (hotels.isEmpty())
            throw new NoItemsMatchQueryException("hotels");

        return hotels.stream()
                .map(hotel -> modelMapper.map(hotel, HotelBookingDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(HotelBookingDTORequest hotelBookingDTORequest) {
        BookingDTORequest bookingDTORequest = hotelBookingDTORequest.getBooking();
        Hotel hotel = hotelService.findByHotelCode(bookingDTORequest.getHotelCode())
                .orElseThrow(() -> new ItemNotFoundException("Hotel", bookingDTORequest.getHotelCode()));
        HotelPackage targetHotelPackage = findTargetHotelPackage(hotel, bookingDTORequest);
        validatePeople(bookingDTORequest);
        validateBooking(bookingDTORequest, targetHotelPackage);

        List<Person> people = personService.conditionallyPersistPeople(bookingDTORequest.getPeople());
        ApiUser apiUser = apiUserService.findByUserName(hotelBookingDTORequest.getUserName());

        SimplePaymentRepresentation spr = PaymentCalculator.calculateHotelPayment(
                targetHotelPackage, bookingDTORequest.getPaymentMethod()
        );

        PaymentMethod paymentMethod = paymentMethodService.createPaymentFromDTO(bookingDTORequest.getPaymentMethod());
        Payment payment = paymentService.createPayment(spr, paymentMethod, null, null);
        HotelBooking hotelBooking = this.save(new HotelBooking(null, LocalDate.now(), targetHotelPackage, null, payment, apiUser));
        List<HotelBookingPerson> hotelBookingPeople = hotelBookingPersonService.createHotelBookingPeople(people, hotelBooking);
        hotelBooking.setHotelBookingPerson(hotelBookingPeople);
        payment.setHotelBooking(hotelBooking);
        paymentService.save(payment);

        targetHotelPackage.setBooked(true);
        hotelPackageService.save(targetHotelPackage);

        return GlobalHelper.createResponse(
                "HotelBooking",
                hotelBooking.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, HotelBookingDTORequest hotelBookingDTORequest) {
        HotelBooking hotelBooking = hotelBookingRepository.findById(id)
                .orElseThrow(() -> new ItemNotFoundException("HotelBooking", id.toString()));
        BookingDTORequest bookingDTORequest = hotelBookingDTORequest.getBooking();

        Hotel hotel = hotelService.findByHotelCode(bookingDTORequest.getHotelCode())
                .orElseThrow(() -> new ItemNotFoundException("Hotel", bookingDTORequest.getHotelCode()));
        HotelPackage targetHotelPackage = findTargetHotelPackage(hotel, bookingDTORequest);

        SimplePaymentRepresentation spr = PaymentCalculator.calculateHotelPayment(
                targetHotelPackage, bookingDTORequest.getPaymentMethod()
        );

        PaymentMethod paymentMethod = paymentMethodService.createPaymentFromDTO(bookingDTORequest.getPaymentMethod());
        Payment payment = paymentService.createPayment(spr, paymentMethod, null, null);
        payment.setHotelBooking(hotelBooking);
        paymentService.save(payment);

        hotelBooking.setPayment(payment);
        this.save(hotelBooking);

        return GlobalHelper.createResponse(
                "HotelBooking",
                hotelBooking.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<HotelBooking> hotel = hotelBookingRepository.findById(id);

        if (hotel.isEmpty())
            throw new ItemNotFoundException("hotel", id.toString());

        hotelBookingRepository.deleteById(hotel.get().getId());
        return GlobalHelper.createResponse(
                "HotelBooking",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public HotelBooking save(HotelBooking hotelBooking) {
        return hotelBookingRepository.save(hotelBooking);
    }

    private void validatePeople(BookingDTORequest bookingReq) {
        System.out.println(bookingReq);
        System.out.println(bookingReq.getPeople().size());
        System.out.println(bookingReq.getPeopleAmount());

        if (bookingReq.getPeople().size() != bookingReq.getPeopleAmount())
            throw new PeopleAmountDoesNotMatchPeopleListException(
                    bookingReq.getPeopleAmount(),
                    bookingReq.getPeople().size()
            );
    }

    private void validateBooking(BookingDTORequest bookingReq, HotelPackage targetHotelPackage) {
        if (targetHotelPackage.isBooked())
            throw new HotelPackageIsAlreadyBookedException(targetHotelPackage);

        if (bookingReq.getRoomType().getCapacity() < bookingReq.getPeopleAmount())
            throw new RoomTypeDoesNotSupportPeopleAmountException(
                    bookingReq.getRoomType().getCapacity(),
                    bookingReq.getPeopleAmount()
            );
    }

    private HotelPackage findTargetHotelPackage(Hotel hotel, BookingDTORequest bookingDTORequest) {
        DateUtil.validateDates(bookingDTORequest.getDateFrom(), bookingDTORequest.getDateTo());

        if (!hotelService.existsWithPlace(bookingDTORequest.getDestination()))
            throw new DestinationOrOriginDoesNotExistException("destination", bookingDTORequest.getDestination(), "hotels");

        List<HotelPackage> matchingPackages = hotel.getHotelPackageList().stream().filter(hp ->
                Objects.equals(hp.getRoomType(), bookingDTORequest.getRoomType()) &&
                        Objects.equals(hp.getDateFrom(), bookingDTORequest.getDateFrom()) &&
                        Objects.equals(hp.getDateTo(), bookingDTORequest.getDateTo())
        ).collect(Collectors.toList());

        if (matchingPackages.isEmpty())
            throw new NoMatchingHotelPackageFoundInHotelException(hotel);

        return matchingPackages.get(0);
    }
}
