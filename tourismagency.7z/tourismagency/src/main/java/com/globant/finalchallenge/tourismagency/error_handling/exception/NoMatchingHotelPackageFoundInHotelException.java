package com.globant.finalchallenge.tourismagency.error_handling.exception;

import com.globant.finalchallenge.tourismagency.model.Hotel;

public class NoMatchingHotelPackageFoundInHotelException extends RuntimeException {
    public NoMatchingHotelPackageFoundInHotelException(Hotel hotel) {
        super(String.format(
                "No matching hotel package found in hotel %s (%s) in %s",
                hotel.getHotelName(),
                hotel.getHotelCode(),
                hotel.getPlace()
        ));
    }
}
