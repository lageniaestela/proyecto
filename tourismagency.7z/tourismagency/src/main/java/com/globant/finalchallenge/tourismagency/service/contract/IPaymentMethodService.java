package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.PaymentMethodDTO;
import com.globant.finalchallenge.tourismagency.model.PaymentMethod;
import org.springframework.stereotype.Service;

public interface IPaymentMethodService extends ICRUD<PaymentMethodDTO, PaymentMethodDTO> {
    public PaymentMethod createPaymentFromDTO(PaymentMethodDTO paymentMethodDTO);
}
