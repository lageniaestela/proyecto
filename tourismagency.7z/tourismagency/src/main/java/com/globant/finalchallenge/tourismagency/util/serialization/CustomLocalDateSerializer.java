package com.globant.finalchallenge.tourismagency.util.serialization;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.globant.finalchallenge.tourismagency.util.GlobalConstants;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;

import java.io.IOException;
import java.time.LocalDate;

public class CustomLocalDateSerializer extends JsonSerializer<LocalDate> {
    @Override
    public void serialize(LocalDate value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeString(GlobalHelper.DATE_TIME_FORMATTER.format(value));
    }
}