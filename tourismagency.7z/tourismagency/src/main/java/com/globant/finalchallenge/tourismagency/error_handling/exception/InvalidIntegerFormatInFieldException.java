package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class InvalidIntegerFormatInFieldException extends RuntimeException {
    public InvalidIntegerFormatInFieldException(String fieldValue, String fieldName) {
        super(String.format(
                "Couldn't parse %s in %s as an integer number",
                fieldValue,
                fieldName
        ));
    }
}