package com.globant.finalchallenge.tourismagency.dto.response.hotel;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.enumerator.RoomType;
import com.globant.finalchallenge.tourismagency.util.deserialization.CustomLocalDateDeserializer;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BodyHotelPackageResponseDTO {
    private String hotelCode;
    private String name;
    private String place;
    private RoomType roomType;
    private BigDecimal roomPrice;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate disponibilityDateFrom;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate disponibilityDateTo;
    private boolean isBooking;
}
