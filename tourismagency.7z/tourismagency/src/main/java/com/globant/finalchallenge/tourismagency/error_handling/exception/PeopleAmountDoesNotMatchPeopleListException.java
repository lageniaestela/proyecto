package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class PeopleAmountDoesNotMatchPeopleListException extends RuntimeException {
    public PeopleAmountDoesNotMatchPeopleListException(int peopleAmount, int peopleListSize) {
        super(String.format(
                "peopleAmount is %s, but people list has %s members",
                peopleAmount,
                peopleListSize
        ));
    }
}
