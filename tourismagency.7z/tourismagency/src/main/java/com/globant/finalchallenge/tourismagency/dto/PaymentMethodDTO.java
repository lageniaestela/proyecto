package com.globant.finalchallenge.tourismagency.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.globant.finalchallenge.tourismagency.enumerator.PaymentType;
import com.globant.finalchallenge.tourismagency.util.deserialization.ValidatedIntegerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PaymentMethodDTO {
    @JsonIgnore
    private Long id;
    @NotBlank
    private String number;
    @Min(1) @Max(12)
    @JsonDeserialize(using = ValidatedIntegerDeserializer.class)
    private Integer dues;
    @JsonProperty("type")
    @Valid
    private PaymentType paymentType;
}
