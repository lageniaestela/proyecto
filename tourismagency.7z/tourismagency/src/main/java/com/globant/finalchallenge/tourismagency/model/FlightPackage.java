package com.globant.finalchallenge.tourismagency.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.enumerator.SeatType;
import com.globant.finalchallenge.tourismagency.util.deserialization.CustomLocalDateDeserializer;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "flight_packages")
public class FlightPackage {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal price;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate dateFrom;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = CustomLocalDateDeserializer.class)
    private LocalDate dateTo;
    private String origin;
    private String destination;
    private String flightPackageNumber;
    private boolean reserved;
    @Enumerated(EnumType.STRING)
    private SeatType seatType;
    @OneToOne(mappedBy = "flightPackage")
    private FlightReservation flightReservation;
    @OneToMany(mappedBy = "flightPackage",cascade = CascadeType.ALL)
    private List<FlightPackageFlight> flightPackageFlights;
}
