package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import org.springframework.stereotype.Service;

public interface IFlightService extends ICRUD<FlightDTO, FlightDTO>{
}
