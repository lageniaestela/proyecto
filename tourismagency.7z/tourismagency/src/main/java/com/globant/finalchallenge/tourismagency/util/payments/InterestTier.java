package com.globant.finalchallenge.tourismagency.util.payments;

import com.globant.finalchallenge.tourismagency.enumerator.PaymentType;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Set;

@Getter
@AllArgsConstructor
public class InterestTier {
    private int duesFrom;
    private int duesTo;
    private BigDecimal interestRate;
    private Set<PaymentType> supportedPaymentMethods;
}
