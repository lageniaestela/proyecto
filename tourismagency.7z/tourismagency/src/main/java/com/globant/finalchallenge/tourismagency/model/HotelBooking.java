package com.globant.finalchallenge.tourismagency.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hotel_bookings")
public class HotelBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    private LocalDate reservationDate;
    @OneToOne
    @JoinColumn(name = "hotel_package_id")
    private HotelPackage hotelPackage;
    @OneToMany(mappedBy = "hotelBooking", cascade = {CascadeType.REMOVE})
    private List<HotelBookingPerson> hotelBookingPerson;
    @OneToOne(cascade = {CascadeType.REMOVE})
    @JoinColumn(name = "payment_id")
    private Payment payment;
    @ManyToOne
    @JoinColumn(name = "api_user_id")
    private ApiUser apiUser;
}
