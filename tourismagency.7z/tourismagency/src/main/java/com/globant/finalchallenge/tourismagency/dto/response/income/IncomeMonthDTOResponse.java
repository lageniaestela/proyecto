package com.globant.finalchallenge.tourismagency.dto.response.income;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IncomeMonthDTOResponse extends IncomeDTOResponse{
    private Integer month;
    private Integer year;

    public IncomeMonthDTOResponse(Integer month, Integer year, Double totalBookingResp, Double totalFlightReservationResp) {
        super(totalBookingResp, totalFlightReservationResp);
        this.month = month;
        this.year = year;
    }
}
