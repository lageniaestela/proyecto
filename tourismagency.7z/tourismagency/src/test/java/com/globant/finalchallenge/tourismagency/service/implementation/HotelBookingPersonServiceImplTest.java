package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.config.ModelMapperConfig;
import com.globant.finalchallenge.tourismagency.dto.HotelBookingPersonDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.model.HotelBookingPerson;
import com.globant.finalchallenge.tourismagency.repository.IHotelBookingPersonRepository;
import com.globant.finalchallenge.tourismagency.test_utils.HotelBookingPersonProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HotelBookingPersonServiceImplTest {
    @Spy
    ModelMapper modelMapper = new ModelMapperConfig().modelMapper();
    @Mock
    IHotelBookingPersonRepository hotelBookingPersonRepository;
    @InjectMocks
    HotelBookingPersonServiceImpl hotelBookingPersonService;

    private List<HotelBookingPerson> dummyHotelBookingPeople;

    @BeforeEach
    void setUp() {
        dummyHotelBookingPeople = HotelBookingPersonProvider.generateHotelBookingPeople();
    }


    @Test
    void findById_personFound() {
        when(hotelBookingPersonRepository.findById(1L)).thenReturn( Optional.of(dummyHotelBookingPeople.get(0)) );

        HotelBookingPersonDTO hotelBookingPerson = hotelBookingPersonService.findById(1L);

        verify(hotelBookingPersonRepository, times(1)).findById(1L);
        assertEquals(
                modelMapper.map(dummyHotelBookingPeople.get(0), HotelBookingPersonDTO.class),
                hotelBookingPerson
        );
    }

    @Test
    void findById_personNotFound() {
        when(hotelBookingPersonRepository.findById(3L)).thenReturn( Optional.empty() );

        assertThrows(ItemNotFoundException.class, () -> hotelBookingPersonService.findById(3L));

        verify(hotelBookingPersonRepository, times(1)).findById(3L);
    }

    @Test
    void findAll() {
        when(hotelBookingPersonRepository.findAll()).thenReturn( dummyHotelBookingPeople );

        List<HotelBookingPersonDTO> hotelBookingPersonDTOs = hotelBookingPersonService.findAll();
    }

    @Test
    void save() {

    }

    @Test
    void update() {

    }

    @Test
    void delete() {

    }
}