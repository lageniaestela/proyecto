package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightPackageFlightDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.FlightPackageFlight;
import com.globant.finalchallenge.tourismagency.repository.IFlightPackageFlightRepository;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FlightPackageFlightServiceImplTest {

    @Mock
    private IFlightPackageFlightRepository flightPackageFlightRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private FlightPackageFlightServiceImpl service;
    private FlightPackageFlight flightPackageFlight;
    private FlightPackageFlightDTO flightPackageFlightDTO;
    private List<FlightPackageFlightDTO> flightPackageFlightDTOs;
    private List<FlightPackageFlight> flightPackageFlights;

    @BeforeEach
    void setUp() {
        flightPackageFlight = new FlightPackageFlight();
        flightPackageFlight.setId(1L);
        flightPackageFlight.setFlightPackage(new FlightPackage());
        flightPackageFlight.setFlightPackage(new FlightPackage());
        flightPackageFlights = new ArrayList<>();
        flightPackageFlights.add(flightPackageFlight);

        flightPackageFlightDTO = new FlightPackageFlightDTO();
        flightPackageFlightDTO.setId(1L);
        flightPackageFlightDTO.setFlightPackage(new FlightPackageDTO());
        flightPackageFlightDTO.setFlight(new FlightDTO());
        flightPackageFlightDTOs = new ArrayList<>();
        flightPackageFlightDTOs.add(flightPackageFlightDTO);

    }

    @Test
    void findByIdShouldReturnAFlightPackage() {
        FlightPackageFlightDTO expectedResult = new FlightPackageFlightDTO(1L,new FlightDTO(), new FlightPackageDTO());
        when(flightPackageFlightRepository.findById(flightPackageFlight.getId())).thenReturn(Optional.of(flightPackageFlight));
        when(modelMapper.map(Optional.of(flightPackageFlight).get(), FlightPackageFlightDTO.class)).thenReturn(flightPackageFlightDTO);

        FlightPackageFlightDTO result = service.findById(flightPackageFlight.getId());

        verify(flightPackageFlightRepository,atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());

        assertEquals(expectedResult.getId(), result.getId());
    }
    @Test
    void findByIdShouldReturnItemNotFoundException() {

        when(flightPackageFlightRepository.findById(flightPackageFlight.getId())).thenReturn(Optional.empty());


        assertThrows(ItemNotFoundException.class, () -> service.findById(flightPackageFlight.getId()));

        verify(flightPackageFlightRepository,atLeastOnce()).findById(any());

    }
    @Test
    void findAllShouldReturnAllFlightPackage() {

        List<FlightPackageFlightDTO> expectedResult = flightPackageFlightDTOs;

        when(flightPackageFlightRepository.findAll()).thenReturn(flightPackageFlights);
        flightPackageFlights.forEach(flightPackageFlight ->
                when(modelMapper.map(Optional.of(flightPackageFlight).get(), FlightPackageFlightDTO.class)).thenReturn(flightPackageFlightDTO));


        List<FlightPackageFlightDTO> result = service.findAll();

        verify(flightPackageFlightRepository,atLeastOnce()).findAll();
        verify(modelMapper, atLeastOnce()).map(any(), any());

        assertEquals(expectedResult.size(), result.size());

    }

    @Test
    void findAllShouldReturnNoItemsMatchQuerySelection() {

        List<FlightPackageFlightDTO> expectedResult = flightPackageFlightDTOs;

        when(flightPackageFlightRepository.findAll()).thenReturn(new ArrayList<>());



        assertThrows(NoItemsMatchQueryException.class, () -> service.findAll());

        verify(flightPackageFlightRepository,atLeastOnce()).findAll();


    }

    @Test
    void saveShouldSaveAFlightPackageFlightAndReturnAMessage() {

        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(flightPackageFlightDTO, FlightPackageFlight.class)).thenReturn(flightPackageFlight);
        when(flightPackageFlightRepository.save(flightPackageFlight)).thenReturn(flightPackageFlight);

        SimpleCRUDResponseDTO result = service.save(flightPackageFlightDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightPackageFlightRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldSaveAFlightPackageFlightAndReturnAMessage() {

        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(flightPackageFlightDTO, FlightPackageFlight.class)).thenReturn(flightPackageFlight);
        when(flightPackageFlightRepository.save(flightPackageFlight)).thenReturn(flightPackageFlight);
        when(flightPackageFlightRepository.existsById(flightPackageFlight.getId())).thenReturn(true);

        SimpleCRUDResponseDTO result = service.update(flightPackageFlightDTO.getId(), flightPackageFlightDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightPackageFlightRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldReturnItemNotFoundException() {


        when(modelMapper.map(flightPackageFlightDTO, FlightPackageFlight.class)).thenReturn(flightPackageFlight);
        when(flightPackageFlightRepository.existsById(flightPackageFlight.getId())).thenReturn(false);

        assertThrows(ItemNotFoundException.class, () -> service.update(flightPackageFlightDTO.getId(), flightPackageFlightDTO));

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(flightPackageFlightRepository, atLeastOnce()).existsById(any());


    }

    @Test
    void deleteShouldDeleteAFlightPackageFlightAndReturnAMessage() {

        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);

        when(flightPackageFlightRepository.findById(flightPackageFlight.getId())).thenReturn(Optional.of(flightPackageFlight));
        doNothing().when(flightPackageFlightRepository).deleteById(flightPackageFlight.getId());

        SimpleCRUDResponseDTO result = service.delete(flightPackageFlightDTO.getId());

        verify(flightPackageFlightRepository, atLeastOnce()).findById(any());
        verify(flightPackageFlightRepository, atLeastOnce()).deleteById(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void deleteShouldReturnItemNotFoundException() {

        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);

        when(flightPackageFlightRepository.findById(flightPackageFlight.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> service.delete(flightPackageFlightDTO.getId()));

        verify(flightPackageFlightRepository, atLeastOnce()).findById(any());

    }
}