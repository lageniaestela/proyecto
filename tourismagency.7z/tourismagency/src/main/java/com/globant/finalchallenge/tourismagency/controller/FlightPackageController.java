package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.dto.response.flight.FlightPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightPackageService;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelPackageService;
import com.globant.finalchallenge.tourismagency.service.implementation.HotelPackageServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("flight-packages")
public class FlightPackageController {

    private static final Logger logger = LoggerFactory.getLogger(FlightPackageController.class);

    private final IFlightPackageService flightPackageService;

    public FlightPackageController(IFlightPackageService flightPackageService) {
        this.flightPackageService = flightPackageService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<FlightPackageResponseDTO> getFlightPackages(@RequestParam(required = false) Optional<String> dateFrom,
                                                                      @RequestParam(required = false) Optional<String> dateTo,
                                                                      @RequestParam(required = false) Optional<String> origin,
                                                                      @RequestParam(required = false) Optional<String> destination) {
        return ResponseEntity.ok()
                .body(flightPackageService.getAllByFilter(dateFrom,dateTo,origin,destination));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<FlightPackageDTO> getFlightPackage(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(flightPackageService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveFlightPackage(@RequestBody @Validated FlightPackageDTO flightPackageDTO) {
        SimpleCRUDResponseDTO responseDTO = flightPackageService.save(flightPackageDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateFlightPackage(
            @PathVariable Long id,
            @RequestBody @Validated FlightPackageDTO flightPackageDTO
    ) {
        SimpleCRUDResponseDTO responseDTO = flightPackageService.update(id, flightPackageDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteFlightPackage(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = flightPackageService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
