package com.globant.finalchallenge.tourismagency.error_handling.exception;

import com.globant.finalchallenge.tourismagency.enumerator.PaymentType;

public class DuesNotSupportedForPaymentTypeException extends RuntimeException {
    public DuesNotSupportedForPaymentTypeException(int dues, PaymentType paymentType) {
        super(String.format(
                "%s dues not supported for payment method: %s",
                dues,
                paymentType.toString()
        ));
    }
}
