package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeDateDTOResponse;
import com.globant.finalchallenge.tourismagency.dto.response.income.IncomeMonthDTOResponse;
import com.globant.finalchallenge.tourismagency.error_handling.exception.InvalidPararameterException;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.repository.IFlightReservationRepository;
import com.globant.finalchallenge.tourismagency.repository.IHotelBookingRepository;
import com.globant.finalchallenge.tourismagency.service.IIncomeService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class IncomeServiceImpl implements IIncomeService {

    private final IHotelBookingRepository hotelBookingRepository;
    private final IFlightReservationRepository flightReservationRepository;

    public IncomeServiceImpl(IHotelBookingRepository hotelBookingRepository, IFlightReservationRepository flightReservationRepository) {
        this.hotelBookingRepository = hotelBookingRepository;
        this.flightReservationRepository = flightReservationRepository;
    }

    @Override
    public IncomeDTOResponse getIncome(String date, Integer month, Integer year) {
        if (date != null && month == null && year == null) {
            System.out.println("using mo and yr");
            if(!GlobalHelper.validateDateFormat(date)) throw new InvalidPararameterException("Invalid date");
            return getIncomeDate(date);
        }
        if (date == null && month != null && year != null) {
            System.out.println("using full date");
            if(!GlobalHelper.validateMonth(month)) throw new InvalidPararameterException("Month is invalid");
            return getIncomeMonth(month, year);
        }
        throw new InvalidPararameterException("Invalid parameters, entry month and year, or date");
    }

    private IncomeDateDTOResponse getIncomeDate(String date) {
        LocalDate theDate = GlobalHelper.simpleParseLocalDateFromString(date);

        List<HotelBooking> bookings = hotelBookingRepository.findByReservationDate(theDate);
        BigDecimal totalBooking = BigDecimal.valueOf(0);
        for (HotelBooking h :
                bookings) {
            totalBooking = totalBooking.add(h.getPayment().getTotal());
        }
        Double totalBookingResp = totalBooking.doubleValue();

        List<FlightReservation> flightReservations = flightReservationRepository.findByReservationDate(theDate);
        BigDecimal totalFlightReservation = BigDecimal.valueOf(0);
        for (FlightReservation f :
                flightReservations) {
            totalFlightReservation = totalFlightReservation.add(f.getPayment().getTotal());
        }
        Double totalFlightReservationResp = totalFlightReservation.doubleValue();
        return new IncomeDateDTOResponse(theDate,totalBookingResp,totalFlightReservationResp);
    }

    private IncomeMonthDTOResponse getIncomeMonth(Integer month, Integer year) {

        //Exception

        List<HotelBooking> bookings = hotelBookingRepository.findByReservationMonthAndYear(month,year);
        BigDecimal totalBooking = BigDecimal.valueOf(0);
        for (HotelBooking h :
                bookings) {
            totalBooking = totalBooking.add(h.getPayment().getTotal());
        }
        Double totalBookingResp = totalBooking.doubleValue();

        List<FlightReservation> flightReservations = flightReservationRepository.findByReservationMonthAndYear(month,year);
        BigDecimal totalFlightReservation = BigDecimal.valueOf(0);
        for (FlightReservation f :
                flightReservations) {
            totalFlightReservation = totalFlightReservation.add(f.getPayment().getTotal());
        }
        Double totalFlightReservationResp = totalFlightReservation.doubleValue();

        return new IncomeMonthDTOResponse(month, year,totalBookingResp,totalFlightReservationResp);
    }
}
