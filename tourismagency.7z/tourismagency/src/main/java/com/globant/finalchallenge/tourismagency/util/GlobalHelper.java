package com.globant.finalchallenge.tourismagency.util;

import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.CustomLocalDateParsingException;
import io.swagger.models.auth.In;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public abstract class GlobalHelper {
    public static final String LOCAL_DATE_FORMAT = "dd/MM/yyyy";
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(LOCAL_DATE_FORMAT);

    public enum CRUDActionType {
        CREATED("created"),
        UPDATED("updated"),
        DELETED("deleted");

        public final String message;

        CRUDActionType(String message) {
            this.message = message;
        }
    }

    public static SimpleCRUDResponseDTO createResponse(String resourceName, String resourceId, CRUDActionType action) {
        return new SimpleCRUDResponseDTO(
                String.format(
                        "%s with id %s %s successfully",
                        resourceName,
                        resourceId,
                        action.message
                )
        );
    }

    public static LocalDate parseLocalDateFromStringWithOptions(String str, String fieldName, boolean allowNull) {
        if (allowNull && str == null) return null;
        else if (!allowNull && str == null) throw new NullPointerException();

        try {
            return LocalDate.parse(str, DATE_TIME_FORMATTER);
        } catch (DateTimeParseException e) {
            throw new CustomLocalDateParsingException(
                    str,
                    LOCAL_DATE_FORMAT,
                    fieldName
            );
        }
    }

    public static LocalDate simpleParseLocalDateFromString(String str) {
        return LocalDate.parse(str, DATE_TIME_FORMATTER);
    }

    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }

    /* verifica el formato de fecha: dd/MM/yyyy */
    public static boolean validateDateFormat(String date){
        return date.matches("^([0][1-9]|[12][0-9]|3[01])(\\/)([0][1-9]|[1][0-2])(\\/)(\\d\\d\\d\\d)$");
    }

    /* verifica que el mes ingresado sea valido*/
    public static boolean validateMonth(Integer month){
        if(month>0 && month<13) return true;
        return false;
    }
}
