package com.globant.finalchallenge.tourismagency.error_handling;

import com.globant.finalchallenge.tourismagency.dto.response.error.ApiError;
import com.globant.finalchallenge.tourismagency.dto.response.error.ValidationError;
import com.globant.finalchallenge.tourismagency.error_handling.exception.*;
import com.globant.finalchallenge.tourismagency.error_handling.exception.security.FailedLoginException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice(annotations = RestController.class)
public class ExceptionControllerAdvice {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionControllerAdvice.class);

//    @ExceptionHandler
//    @ResponseBody
//    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
//    public ApiError handleException(Exception ex) {
//
//        StringWriter sw = new StringWriter();
//        ex.printStackTrace(new PrintWriter(sw));
//
//        return new ApiError(
//                HttpStatus.INTERNAL_SERVER_ERROR.value(),
//                ex.getClass().getName(),
//                ex.getMessage());
//    }


    @ExceptionHandler({ org.springframework.http.converter.HttpMessageNotReadableException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ApiError deserializerException(Exception ex) {
        logger.info("Deserializer error exception when read the json file");
        return new ApiError(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                ex.getClass().getName(),
                "Exception when trying to deserialize json");
    }

    @ExceptionHandler({
            ItemNotFoundException.class,
            NoItemsMatchQueryException.class,
            NoMatchingHotelPackageFoundInHotelException.class,
            HotelWithCodeNotExists.class
    })
    @ResponseBody
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ApiError handleNotFoundExceptions(RuntimeException e) {
        logger.error(e.getMessage());
        return new ApiError(
                HttpStatus.NOT_FOUND.value(),
                e.getClass().getName(),
                e.getMessage()
        );
    }

    @ExceptionHandler({
            InvalidPararameterException.class,
            CustomLocalDateParsingException.class,
            DestinationOrOriginDoesNotExistException.class,
            InvalidIntegerFormatInFieldException.class,
            LocalDateFromIsAfterToException.class,
            HotelPackageIsAlreadyBookedException.class,
            PeopleAmountDoesNotMatchPeopleListException.class,
            DuesNotSupportedForPaymentTypeException.class,
            FailedLoginException.class,
            PackageCannotBeEditedOrDeletedException.class,
            UserNameMustBeUniqueException.class,
            HotelPackageCannotBeEditedOrDeletedException.class
    })
    @ResponseBody
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ApiError handleGenericBadRequestExceptions(RuntimeException e) {
        logger.error(e.getMessage());
        return new ApiError(
                HttpStatus.BAD_REQUEST.value(),
                e.getClass().getName(),
                e.getMessage()
        );
    }



///*    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    @ExceptionHandler({
//            BadRequestException.class,
//            org.springframework.web.bind.MissingServletRequestParameterException.class})
//    @ResponseBody
//    public ApiError requiredParamException(org.springframework.web.bind.MissingServletRequestParameterException ex) {
//        logger.info("Required param exception");
//        return new ApiError(
//                HttpStatus.BAD_REQUEST.value(),
//                ex.getClass().getName(),
//                "All the params are required");
//    }

    @ExceptionHandler
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public List<ValidationError> handleException(MethodArgumentNotValidException ex) {
        return ex.getBindingResult().getAllErrors()
                .stream()
                .map(this::mapError)
                .collect(Collectors.toList());
    }

    private ValidationError mapError(ObjectError objectError) {
        if (objectError instanceof FieldError) {
            return new ValidationError(((FieldError) objectError).getField(),
                    objectError.getDefaultMessage());
        }
        return new ValidationError(objectError.getObjectName(), objectError.getDefaultMessage());
    }


    @ExceptionHandler({java.util.NoSuchElementException.class})
    @ResponseBody
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ApiError noSuchElementException(java.util.NoSuchElementException ex){
        logger.info("No such element exception");
        return new ApiError(
                HttpStatus.NOT_FOUND.value(),
                ex.getClass().getName(),
                "Element not found");
    }
}