package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.PaymentDTO;
import com.globant.finalchallenge.tourismagency.dto.PaymentDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.LocalDateFromIsAfterToException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.*;
import com.globant.finalchallenge.tourismagency.repository.IPaymentMethodRepository;
import com.globant.finalchallenge.tourismagency.repository.IPaymentRepository;
import com.globant.finalchallenge.tourismagency.test_utils.HotelBookingProvider;
import com.globant.finalchallenge.tourismagency.test_utils.PaymentMethodProvider;
import com.globant.finalchallenge.tourismagency.test_utils.PaymentProvider;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PaymentServiceImplTest {
    @Mock
    private IPaymentRepository paymentRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private PaymentServiceImpl paymentService;

    private HotelBooking hotelBooking;
    private FlightReservation flightReservation;
    private PaymentMethod paymentMethod;
    private Payment simplePayment;
    private PaymentDTO simplePaymentDTO;
    private List<Payment> paymentList;
    private List<PaymentDTO> paymentDTOList;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
        hotelBooking = HotelBookingProvider.generateHotelBooking(1L);
        paymentMethod = PaymentMethodProvider.generatePaymentMethod();
        simplePayment = PaymentProvider.generateBookingDebitCardPayment(1L);
        simplePaymentDTO = PaymentProvider.generateBookingDebitCardPaymentDTO(1L);

        paymentList = PaymentProvider.generatePaymentList();
        paymentDTOList = PaymentProvider.generatePaymentDTOList();
    }


    @Test
    void whenSaveThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Payment",
                simplePayment.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(simplePaymentDTO, Payment.class)).thenReturn(simplePayment);
        when(paymentRepository.save(simplePayment)).thenReturn(simplePayment);

        SimpleCRUDResponseDTO result = paymentService.save(simplePaymentDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(paymentRepository, atLeastOnce()).save(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    // findAll
    @Test
    void whenFindAllThenSuccess() {
        when(paymentRepository.findAll()).thenReturn(paymentList);
        IntStream.range(0, paymentList.size())
                .forEach(i -> when(modelMapper.map(paymentList.get(i), PaymentDTO.class))
                        .thenReturn(paymentDTOList.get(i)));

        assertEquals(paymentDTOList, paymentService.findAll());
    }
    @Test
    void whenFindAllThenThrowNoItemsMatchQueryException(){
        when(paymentRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, () -> paymentService.findAll());
        verify(paymentRepository, atLeastOnce()).findAll();
    }

    // findById
    @Test
    void whenFindByIdThenSuccess() {
        PaymentDTO expectedResult = simplePaymentDTO;

        when(paymentRepository.findById(simplePayment.getId())).
                thenReturn(Optional.of(simplePayment));
        when(modelMapper.map(Optional.of(simplePayment).get(), PaymentDTO.class)).
                thenReturn(simplePaymentDTO);

        PaymentDTO result = paymentService.findById(simplePayment.getId());

        verify(paymentRepository, atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());
        assertEquals(expectedResult, result);
    }
    @Test
    void whenFindByIdThenThrowItemNotFoundException(){
        when(paymentRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> paymentService.findById(1L));
        verify(paymentRepository, atLeastOnce()).findById(1L);
    }

    // delete
    @Test
    void whenDeleteThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Payment",
                simplePayment.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(paymentRepository.findById(simplePayment.getId())).thenReturn(Optional.of(simplePayment));
        doNothing().when(paymentRepository).deleteById(simplePayment.getId());

        SimpleCRUDResponseDTO result = paymentService.delete(simplePayment.getId());

        verify(paymentRepository, atLeastOnce()).findById(any());
        verify(paymentRepository, atLeastOnce()).deleteById(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }
    @Test
    void whenDeleteThrowItemNotFoundException(){
        when(paymentRepository.findById(simplePayment.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> paymentService.delete(simplePayment.getId()));
        verify(paymentRepository, atLeastOnce()).findById(any());
    }

    // update
    @Test
    void whenUpdateThenSuccess(){
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Payment",
                simplePayment.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(simplePaymentDTO, Payment.class)).thenReturn(simplePayment);
        when(paymentRepository.existsById(simplePaymentDTO.getId())).thenReturn(true);
        when(paymentRepository.save(simplePayment)).thenReturn(simplePayment);

        SimpleCRUDResponseDTO result = paymentService.update(simplePaymentDTO.getId(), simplePaymentDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(paymentRepository, atLeastOnce()).existsById(any());
        verify(paymentRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }
    @Test
    void updateShouldReturnItemNotFoundException() {
        when(modelMapper.map(simplePaymentDTO, Payment.class)).thenReturn(simplePayment);
        when(paymentRepository.existsById(simplePayment.getId())).thenReturn(false);

        assertThrows(ItemNotFoundException.class, () -> paymentService.update(1L, simplePaymentDTO));
        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(paymentRepository, atLeastOnce()).existsById(any());
    }

}
