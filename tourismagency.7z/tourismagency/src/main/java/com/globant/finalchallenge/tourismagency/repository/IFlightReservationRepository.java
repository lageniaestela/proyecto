package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IFlightReservationRepository extends JpaRepository<FlightReservation,Long> {
    @Query("select f from FlightReservation f where f.reservationDate = :date")
    List<FlightReservation> findByReservationDate(@Param("date") LocalDate theDate);

    @Query("select f from FlightReservation f where month(f.reservationDate) = :m " +
            "and year(f.reservationDate) = :y")
    List<FlightReservation> findByReservationMonthAndYear(@Param("m") Integer month, @Param("y") Integer year);
}
