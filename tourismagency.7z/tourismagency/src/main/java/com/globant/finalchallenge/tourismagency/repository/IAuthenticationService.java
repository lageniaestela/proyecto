package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.LoginDataDTO;

import javax.servlet.http.HttpServletResponse;

public interface IAuthenticationService {
    String login(LoginDataDTO loginData, HttpServletResponse response);

    ApiUserDTO register(LoginDataDTO loginData);
}
