package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelDTO;
import com.globant.finalchallenge.tourismagency.dto.PersonDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.model.Person;
import com.globant.finalchallenge.tourismagency.repository.IPersonRepository;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PersonServiceImplTest {
    @Mock
    private IPersonRepository personRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private PersonServiceImpl personService;
    private Person person;
    private Person person2;
    private Person person3;
    private PersonDTO personDTO;
    private PersonDTO personDTO2;
    private PersonDTO personDTO3;
    private List<Person> persons = new ArrayList<>();
    private List<PersonDTO> personsDTO = new ArrayList<>();

    @BeforeEach
    void setUp(){
        person = new Person();
        person.setId(1L);
        person.setName("Pedro");
        person.setLastName("Gutierrez");
        person.setDni("12345678");

        person2 = new Person();
        person2.setId(2L);
        person2.setName("Pepe");
        person2.setLastName("Bustamante");
        person2.setDni("12345678");

        person3 = new Person();
        person3.setId(3L);
        person3.setName("Ricardo");
        person3.setLastName("De Angelis");
        person3.setDni("12345678");

        personDTO = new PersonDTO();
        personDTO.setId(1L);
        personDTO.setName("Pedro");
        personDTO.setLastName("Gutierrez");
        personDTO.setDni("12345678");

        personDTO2 = new PersonDTO();
        personDTO2.setId(2L);
        personDTO2.setName("Pepe");
        personDTO2.setLastName("Bustamante");
        personDTO2.setDni("12345678");

        personDTO3 = new PersonDTO();
        personDTO3.setId(3L);
        personDTO3.setName("Ricardo");
        personDTO3.setLastName("De Angelis");
        personDTO3.setDni("12345678");

        persons.add(person);
        persons.add(person2);
        persons.add(person3);

        personsDTO.add(personDTO);
        personsDTO.add(personDTO2);
        personsDTO.add(personDTO3);

    }
    @Test
    void findByIdShouldReturnAPerson() {
        PersonDTO expectedResult = new PersonDTO();
        expectedResult.setId(1L);
        expectedResult.setName("Pedro");
        expectedResult.setLastName("Gutierrez");
        expectedResult.setDni("12345678");
        when(personRepository.findById(person.getId())).thenReturn(Optional.of(person));
        when(modelMapper.map(Optional.of(person).get(), PersonDTO.class)).thenReturn(personDTO);

        PersonDTO result = personService.findById(personDTO.getId());

        verify(personRepository, atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());
        assertEquals(expectedResult.getName(), result.getName());
    }

    @Test
    void findByIdShouldReturnItemNotFoundException() {
        when(personRepository.findById(person.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> personService.findById(person.getId()));
        verify(personRepository, atLeastOnce()).findById(any());
    }

    @Test
    void findAllShouldReturnAllThePersons() {
        List<PersonDTO> expectedResult = personsDTO;
        when(personRepository.findAll()).thenReturn(persons);
        for (int i = 0; i < 3; i++) {
            when(modelMapper.map(persons.get(i), PersonDTO.class)).thenReturn(personsDTO.get(i));
        }
        List<PersonDTO> result = personService.findAll();

        verify(personRepository, atLeastOnce()).findAll();
        verify(modelMapper, atLeast(3)).map(any(), any());
        assertEquals(expectedResult.size(), result.size());
        assertEquals(expectedResult, result);
        assertEquals(expectedResult.get(2).getName(), result.get(2).getName());
    }

    @Test
    void findAllShouldReturnNoItemsMatchQuerySelection() {
        when(personRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, () -> personService.findAll());
        verify(personRepository, atLeastOnce()).findAll();
    }

    @Test
    void saveShouldSaveAPersonAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Person",
                person.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(personDTO, Person.class)).thenReturn(person);
        when(personRepository.save(person)).thenReturn(person);

        SimpleCRUDResponseDTO result = personService.save(personDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(personRepository, atLeastOnce()).save(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldUpdateAPersonAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Person",
                person.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(personDTO, Person.class)).thenReturn(person);
        when(personRepository.existsById(personDTO.getId())).thenReturn(true);
        when(personRepository.save(person)).thenReturn(person);

        SimpleCRUDResponseDTO result = personService.update(personDTO.getId(), personDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(personRepository, atLeastOnce()).existsById(any());
        verify(personRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldReturnItemNotFoundException() {
        when(modelMapper.map(personDTO, Person.class)).thenReturn(person);
        when(personRepository.existsById(person.getId())).thenReturn(false);

        assertThrows(ItemNotFoundException.class, () -> personService.update(1L, personDTO));
        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(personRepository, atLeastOnce()).existsById(any());
    }

    @Test
    void deleteShouldDeleteAPersonAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Person",
                person.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(personRepository.findById(person.getId())).thenReturn(Optional.of(person));
        doNothing().when(personRepository).deleteById(person.getId());

        SimpleCRUDResponseDTO result = personService.delete(person.getId());

        verify(personRepository, atLeastOnce()).findById(any());
        verify(personRepository, atLeastOnce()).deleteById(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void deleteShouldReturnItemNotFoundException() {
        when(personRepository.findById(person.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> personService.delete(1L));
        verify(personRepository, atLeastOnce()).findById(any());
    }
}