package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.repository.IHotelRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class HotelServiceImpl implements IHotelService {
    private final IHotelRepository hotelRepository;
    private final ModelMapper modelMapper;

    public HotelServiceImpl(IHotelRepository hotelRepository, ModelMapper modelMapper) {
        this.hotelRepository = hotelRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public HotelDTO findById(Long id) {
        Optional<Hotel> result = hotelRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("Hotel", id.toString());

        return modelMapper.map(result.get(), HotelDTO.class);
    }

    @Override
    public List<HotelDTO> findAll() {
        List<Hotel> hotels = hotelRepository.findAll();

        if (hotels.isEmpty())
            throw new NoItemsMatchQueryException("hotels");

        return hotels.stream()
                .map(hotel -> modelMapper.map(hotel, HotelDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(HotelDTO hotelDTO) {
        Hotel hotel = modelMapper.map(hotelDTO, Hotel.class);
        hotel = hotelRepository.save(hotel);
        return GlobalHelper.createResponse(
                "Hotel",
                hotel.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, HotelDTO hotelDTO) {
        Hotel hotel = modelMapper.map(hotelDTO, Hotel.class);
        hotel.setId(id);

        if (!hotelRepository.existsById(id))
            throw new ItemNotFoundException("hotel", id.toString());

        hotel = hotelRepository.save(hotel);
        return GlobalHelper.createResponse(
                "Hotel",
                hotel.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<Hotel> hotel = hotelRepository.findById(id);

        if (hotel.isEmpty())
            throw new ItemNotFoundException("hotel", id.toString());

        hotelRepository.deleteById(hotel.get().getId());
        return GlobalHelper.createResponse(
                "Hotel",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public Optional<Hotel> findByHotelCode(String hotelCode) {
        return hotelRepository.findByHotelCode(hotelCode);
    }

    @Override
    public boolean existsWithPlace(String place) {
        return hotelRepository.existsByPlace(place);
    }
}
