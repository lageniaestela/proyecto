package com.globant.finalchallenge.tourismagency.error_handling.exception;

import com.globant.finalchallenge.tourismagency.util.GlobalHelper;

public class HotelWithCodeNotExists extends RuntimeException {
    public HotelWithCodeNotExists(String codeHotel) {
        super(String.format(
                "Hotel with code %s does not exist",
                codeHotel
        ));
    }
}
