package com.globant.finalchallenge.tourismagency.util;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;
import com.globant.finalchallenge.tourismagency.dto.HotelPackageDTO;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.HotelPackage;

public abstract class AuxMapper {
    public static HotelPackage map(HotelPackageDTO hotelPackageDTO){
        return new HotelPackage(
                null,
                hotelPackageDTO.getRoomPrice(),
                hotelPackageDTO.getDateFrom(),
                hotelPackageDTO.getDateTo(),
                false,
                hotelPackageDTO.getRoomType(),
                null,
                null
        );
    }

    public static FlightPackage map(FlightPackageDTO flightPackageDTO){
         return new FlightPackage(
                null,
                flightPackageDTO.getPrice(),
                flightPackageDTO.getDateFrom(),
                flightPackageDTO.getDateTo(),
                flightPackageDTO.getOrigin(),
                flightPackageDTO.getDestination(),
                flightPackageDTO.getFlightPackageNumber(),
                false,
                flightPackageDTO.getSeatType(),
                null,
                null
        );

    }

    public static FlightDTO map(Flight flight){
        return new FlightDTO(
                flight.getId(),
                flight.getOrigin(),
                flight.getDestination(),
                flight.getDeparture(),
                flight.getArrival()
        );

    }
}
