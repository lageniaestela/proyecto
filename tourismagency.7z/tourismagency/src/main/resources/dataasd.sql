use tourism_agency;

insert into flights (id, departure, arrival, destination, origin)
values (1, '2021-05-20', '2021-05-20', 'Argentina', 'Colombia'),
       (2, '2021-06-05', '2021-06-05', 'Colombia', 'Argentina'),
       (3, '2021-07-20', '2021-07-21', 'Perú', 'Colombia'),
       (4, '2021-07-27', '2021-07-28', 'Colombia', 'Perú'),
       (5, '2021-01-06', '2021-01-07', 'Chile', 'Puerto Rico'),
       (6, '2021-02-07', '2021-02-08', 'Puerto Rico', 'Chile'),
       (7, '2021-10-20', '2021-10-20', 'Inglaterra', 'Estados Unidos'),
       (8, '2021-05-20', '2021-05-20', 'Estados Unidos', 'Inglaterra');

insert into people (id, birth_date, dni, name, last_name, mail)
values (1, '2000-04-04', '12345678', 'Ricardo', 'Perez', 'ricardo.perez@gmail.com'),
       (2, '1999-05-02', '12345678', 'Raul', 'Perez', 'raul.perez@gmail.com'),
       (3, '1998-06-28', '12345678', 'Rigoberto', 'Perez', 'rigoberto.perez@gmail.com'),
       (4, '1997-03-22', '12345678', 'Roberto', 'Perez', 'roberto.perez@gmail.com'),
       (5, '1964-08-01', '12345678', 'Mario', 'Perez', 'mario.perez@gmail.com'),
       (6, '1965-12-14', '12345678', 'Laura', 'Rodriguez', 'laura.rodriguez@gmail.com'),
       (7, '1982-04-04', '12345678', 'Román', 'Ivañez', 'roman.ivañez@gmail.com'),
       (8, '1975-11-13', '12345678', 'Azul', 'Gomez', 'azul.gomez@gmail.com'),
       (9, '1977-01-02', '12345678', 'Sofía', 'Malbi', 'sofia.malbi@gmail.com'),
       (10, '1976-03-23', '12345678', 'Santiago', 'Demalipchak', 'santiago.demalipchak@gmail.com'),
       (11, '1952-02-12', '12345678', 'Inés', 'Lagos', 'ines.lagos@gmail.com'),
       (12, '2002-04-09', '12345678', 'Mariana', 'Vega', 'mariana.vega@gmail.com'),
       (13, '2001-06-28', '12345678', 'Agustina', 'Montevich', 'agustina.montevich@gmail.com'),
       (14, '2000-09-04', '12345678', 'Osvaldo', 'Lopez', 'osvaldo.lopez@gmail.com');

insert into api_users (id, user_name, password, role_type, person_id)
values (1, 'user1@mail.com', 'Password123', 'ROLE_CLIENT', 1),
       (2, 'user2@mail.com', 'Password123', 'ROLE_CLIENT', 2),
       (3, 'user3@mail.com', 'Password123', 'ROLE_CLIENT', 3),
       (4, 'user4@mail.com', 'Password123', 'ROLE_CLIENT', 4),
       (5, 'user5@mail.com', 'Password123', 'ROLE_EMPLOYEE', 5),
       (6, 'user6@mail.com', 'Password123', 'ROLE_EMPLOYEE', 6);


insert into flight_packages (id, date_from, date_to, origin, destination, flight_package_number, price, seat_type, reserved)
values (1, '2021-05-20', '2021-06-05','Argentina', 'Colombia', 'ARCO-0002', 20000, 'ECONOMY', false),
       (2, '2021-05-20', '2021-06-05','Argentina', 'Colombia', 'ARCO-0003', 43000, 'BUSINESS', false),
       (3, '2021-07-20', '2021-05-30', 'Peru', 'Colombia', 'PECO-0005', 23000, 'ECONOMY', false),
       (4, '2021-05-20', '2021-05-30','Peru', 'Colombia', 'PECO-0006', 43000, 'BUSINESS', false),
       (5, '2021-05-20', '2021-05-30', 'Buenos Aires', 'Puerto Iguazu', 'BAPI-0004', 20000, 'ECONOMY', false),
       (6, '2021-05-20', '2021-05-30', 'Buenos Aires', 'Puerto Iguazu', 'BAPI-0005', 20000, 'ECONOMY', false);


insert into hotels (id, hotel_code, hotel_name, place)
values (1, 'LH-0001', 'LovelyHotel', 'Colombia'),
       (2, 'PO-0001', 'Poseidón', 'Argentina'),
       (3, 'ZE-0001', 'Zeus', 'Perú'),
       (4, 'HA-0001', 'Hades', 'Puerto Rico'),
       (5, 'HE-0001', 'Hefesto', 'Estados Unidos');

insert into hotel_packages (id, booked, date_from, date_to, room_price, room_type, hotel_id)
values (1, false, '2021-01-01', '2021-01-23', '4000', 'SINGLE', 1),
       (2, false, '2021-02-01', '2021-03-13', '4000', 'DOUBLE', 2),
       (3, false, '2021-02-01', '2021-03-15', '8000', 'TRIPLE', 2),
       (4, false, '2021-02-01', '2021-03-14', '16000', 'MULTIPLE', 2),
       (5, false, '2021-11-01', '2021-11-08', '20000', 'SINGLE', 3),
       (6, false, '2021-11-01', '2021-11-09', '40000', 'DOUBLE', 3),
       (7, false, '2021-11-01', '2021-11-09', '50000', 'TRIPLE', 3),
       (8, false, '2021-05-15', '2021-05-23', '13000', 'DOUBLE', 4),
       (9, false, '2021-05-15', '2021-05-24', '20000', 'TRIPLE', 4),
       (10, false, '2021-05-15', '2021-05-25', '40000', 'MULTIPLE', 4),
       (11, false, '2021-03-01', '2021-04-01', '8000', 'DOUBLE', 5),
       (12, false, '2021-03-01', '2021-04-01', '15000', 'TRIPLE', 5),
       (13, false, '2021-03-01', '2021-04-01', '30000', 'MULTIPLE', 5);




insert into payment_methods (id, dues, number, payment_type)
values (1, 1, '1111-1111-1111-1111', 'CREDIT'),
       (2, 1, '2222-2222-2222-2222', 'CREDIT'),
       (3, 1, '3333-3333-3333-3333', 'CREDIT'),
       (4, 1, '4444-4444-4444-4444', 'CREDIT'),
       (5, 1, '5555-5555-5555-5555', 'CREDIT'),
       (6, 1, '6666-6666-6666-6666', 'CREDIT'),
       (7, 1, '7777-7777-7777-7777', 'CREDIT'),
       (8, 1, '8888-8888-8888-8888', 'CREDIT');

insert into payments (id, interest, total, without_interest, payment_method_id)
values (1, 1, 5, 2, 1),
       (2, 1, 6, 3, 2),
       (3, 1, 5, 4, 3),
       (4, 1, 6, 5, 4),
       (5, 1, 5, 2, 5),
       (6, 1, 6, 3, 6),
       (7, 1, 5, 4, 7),
       (8, 1, 6, 5, 8);

insert into hotel_bookings (id, reservation_date, api_user_id, hotel_package_id, payment_id)
values (1, '2021-01-11', 5, 2, 1),
       (2, '2021-01-11', 6, 3, 2),
       (3, '2021-01-13', 5, 4, 3),
       (4, '2021-02-14', 6, 5, 4);

insert into flight_reservations (id, reservation_date, api_user_id, flight_package_id, payment_id)
values (1, '2021-01-11', 5, 2, 5),
      (2, '2021-01-12', 6, 3, 6),
      (3, '2021-02-11', 5, 4, 7),
      (4, '2021-02-14', 6, 5, 8);



INSERT INTO flight_packages_flight (flight_id, flight_package_id) VALUES ('1', '1');
