package com.globant.finalchallenge.tourismagency.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.globant.finalchallenge.tourismagency.enumerator.RoleType;
import com.globant.finalchallenge.tourismagency.model.FlightReservation;
import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApiUserDTO {
    @JsonIgnore
    private Long id;
    @NotNull(message = "The field cannot be null")
    @NotBlank(message = "The field cannot be blank")
    @Email
    private String userName;
    private String password;
    private RoleType roleType;
    private List<HotelBooking> hotelBookings;
    private List<FlightReservation> flightReservations;
}
