package com.globant.finalchallenge.tourismagency.controller;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightService;
import com.globant.finalchallenge.tourismagency.service.implementation.FlightServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("flights")
public class FlightController {
    private static final Logger logger = LoggerFactory.getLogger(FlightController.class);

    private final IFlightService flightService;

    public FlightController(FlightServiceImpl flightService) {
        this.flightService = flightService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<List<FlightDTO>> getFlights() {
        return ResponseEntity.ok()
                .body(flightService.findAll());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<FlightDTO> getFlight(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(flightService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveFlight(@RequestBody @Validated FlightDTO flightDTO) {
        SimpleCRUDResponseDTO responseDTO = flightService.save(flightDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateFlight(
            @PathVariable Long id,
            @RequestBody @Validated FlightDTO flightDTO
    ) {
        SimpleCRUDResponseDTO responseDTO = flightService.update(id, flightDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteFlight(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = flightService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
