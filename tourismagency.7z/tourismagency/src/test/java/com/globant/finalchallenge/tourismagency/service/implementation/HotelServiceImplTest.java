package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.HotelDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import com.globant.finalchallenge.tourismagency.repository.IHotelRepository;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HotelServiceImplTest {

    @Mock
    private IHotelRepository hotelRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private HotelServiceImpl hotelService;
    private Hotel hotel;
    private Hotel hotel2;
    private Hotel hotel3;
    private HotelDTO hotelDTO;
    private HotelDTO hotelDTO2;
    private HotelDTO hotelDTO3;
    private List<Hotel> hotels = new ArrayList<>();
    private List<HotelDTO> hotelsDTO = new ArrayList<>();

    @BeforeEach
    void setUp() {
        hotel = new Hotel();
        hotel.setId(1L);
        hotel.setHotelCode("HH-2020");
        hotel.setHotelName("Hotel Test");
        hotel.setPlace("Tucuman");

        hotel2 = new Hotel();
        hotel2.setId(2L);
        hotel2.setHotelCode("HH-2021");
        hotel2.setHotelName("Hotel Test2");
        hotel2.setPlace("Tucuman");

        hotel3 = new Hotel();
        hotel3.setId(3L);
        hotel3.setHotelCode("HH-2022");
        hotel3.setHotelName("Hotel Test3");
        hotel3.setPlace("Tucuman");

        hotelDTO = new HotelDTO(1L, "HH-2020", "Hotel Test", "Tucuman");
        hotelDTO2 = new HotelDTO(2L, "HH-2021", "Hotel Test2", "Tucuman");
        hotelDTO3 = new HotelDTO(3L, "HH-2022", "Hotel Test3", "Tucuman");

        hotels.add(hotel);
        hotels.add(hotel2);
        hotels.add(hotel3);

        hotelsDTO.add(hotelDTO);
        hotelsDTO.add(hotelDTO2);
        hotelsDTO.add(hotelDTO3);
    }

    @Test
    void findByIdShouldReturnAHotel() {
        HotelDTO expectedResult = new HotelDTO(1L, "HH-2020", "Hotel Test", "Tucuman");
        when(hotelRepository.findById(hotel.getId())).thenReturn(Optional.of(hotel));
        when(modelMapper.map(Optional.of(hotel).get(), HotelDTO.class)).thenReturn(hotelDTO);

        HotelDTO result = hotelService.findById(hotelDTO.getId());

        verify(hotelRepository, atLeastOnce()).findById(any());
        verify(modelMapper, atLeastOnce()).map(any(), any());
        assertEquals(expectedResult.getHotelCode(), result.getHotelCode());
    }

    @Test
    void findByIdShouldReturnItemNotFoundException() {
        when(hotelRepository.findById(hotel.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> hotelService.findById(hotel.getId()));
        verify(hotelRepository, atLeastOnce()).findById(any());
    }

    @Test
    void findAllShouldReturnAllTheHotels() {
        List<HotelDTO> expectedResult = hotelsDTO;
        when(hotelRepository.findAll()).thenReturn(hotels);
        for (int i = 0; i < 3; i++) {
            when(modelMapper.map(hotels.get(i), HotelDTO.class)).thenReturn(hotelsDTO.get(i));
        }
        List<HotelDTO> result = hotelService.findAll();

        verify(hotelRepository, atLeastOnce()).findAll();
        verify(modelMapper, atLeast(3)).map(any(), any());
        assertEquals(expectedResult.size(), result.size());
        assertEquals(expectedResult, result);
        assertEquals(expectedResult.get(2).getHotelCode(), result.get(2).getHotelCode());
    }

    @Test
    void findAllShouldReturnNoItemsMatchQuerySelection() {
        when(hotelRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(NoItemsMatchQueryException.class, () -> hotelService.findAll());
        verify(hotelRepository, atLeastOnce()).findAll();
    }

    @Test
    void saveShouldSaveAHotelAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Hotel",
                hotel.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED);
        when(modelMapper.map(hotelDTO, Hotel.class)).thenReturn(hotel);
        when(hotelRepository.save(hotel)).thenReturn(hotel);

        SimpleCRUDResponseDTO result = hotelService.save(hotelDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(hotelRepository, atLeastOnce()).save(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldUpdateAHotelAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Hotel",
                hotel.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED);
        when(modelMapper.map(hotelDTO, Hotel.class)).thenReturn(hotel);
        when(hotelRepository.existsById(hotelDTO.getId())).thenReturn(true);
        when(hotelRepository.save(hotel)).thenReturn(hotel);

        SimpleCRUDResponseDTO result = hotelService.update(hotelDTO.getId(), hotelDTO);

        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(hotelRepository, atLeastOnce()).existsById(any());
        verify(hotelRepository, atLeastOnce()).save(any());

        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void updateShouldReturnItemNotFoundException() {
        when(modelMapper.map(hotelDTO, Hotel.class)).thenReturn(hotel);
        when(hotelRepository.existsById(hotel.getId())).thenReturn(false);

        assertThrows(ItemNotFoundException.class, () -> hotelService.update(1L, hotelDTO));
        verify(modelMapper, atLeastOnce()).map(any(), any());
        verify(hotelRepository, atLeastOnce()).existsById(any());
    }

    @Test
    void deleteShouldDeleteAHotelAndReturnAMessage() {
        SimpleCRUDResponseDTO expectedResult = GlobalHelper.createResponse("Hotel",
                hotel.getId().toString(),
                GlobalHelper.CRUDActionType.DELETED);
        when(hotelRepository.findById(hotel.getId())).thenReturn(Optional.of(hotel));
        doNothing().when(hotelRepository).deleteById(hotel.getId());

        SimpleCRUDResponseDTO result = hotelService.delete(hotel.getId());

        verify(hotelRepository, atLeastOnce()).findById(any());
        verify(hotelRepository, atLeastOnce()).deleteById(any());
        assertEquals(expectedResult.getMessage(), result.getMessage());
    }

    @Test
    void deleteShouldReturnItemNotFoundException() {
        when(hotelRepository.findById(hotel.getId())).thenReturn(Optional.empty());

        assertThrows(ItemNotFoundException.class, () -> hotelService.delete(1L));
        verify(hotelRepository, atLeastOnce()).findById(any());
    }
}