package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class InconsistentFlightData extends RuntimeException {
    public InconsistentFlightData(Long flightId) {
        super(String.format(
                "There is a flight with id: %d but has different information",
                flightId
        ));
    }
}
