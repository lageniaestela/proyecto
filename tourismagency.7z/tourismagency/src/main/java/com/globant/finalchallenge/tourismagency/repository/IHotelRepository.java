package com.globant.finalchallenge.tourismagency.repository;

import com.globant.finalchallenge.tourismagency.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IHotelRepository extends JpaRepository<Hotel,Long> {
    Optional<Hotel> findByHotelCode(String str);
    boolean existsByPlace(String str);
}
