package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.model.Flight;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class
FlightProvider {
    private FlightProvider(){}

    public static List<Flight> findAll(){
        List<Flight> flightList = new ArrayList<>();
        flightList.add(new Flight(1L,
                "Argentina",
                "Chile",
                LocalDate.of(2022, 1, 1),
                LocalDate.of(2022, 1, 1),
                null
                ));
        flightList.add(new Flight(2L,
                "Chile",
                "Argentina",
                LocalDate.of(2022, 1, 7),
                LocalDate.of(2022, 1, 7),
                null
        ));
        flightList.add(new Flight(3L,
                "Perú",
                "Bolivia",
                LocalDate.of(2022, 4, 4),
                LocalDate.of(2022, 4, 5),
                null
        ));
        flightList.add(new Flight(4L,
                "Bolivia",
                "Perú",
                LocalDate.of(2022, 4, 15),
                LocalDate.of(2022, 4, 16),
                null
        ));

        return flightList;
    }

    public static List<FlightDTO> findAllDTO(){
        List<FlightDTO> flightList = new ArrayList<>();
        flightList.add(new FlightDTO(1L,
                "Argentina",
                "Chile",
                LocalDate.of(2022, 1, 1),
                LocalDate.of(2022, 1, 1)
        ));
        flightList.add(new FlightDTO(2L,
                "Chile",
                "Argentina",
                LocalDate.of(2022, 1, 7),
                LocalDate.of(2022, 1, 7)
        ));
        flightList.add(new FlightDTO(3L,
                "Perú",
                "Bolivia",
                LocalDate.of(2022, 4, 4),
                LocalDate.of(2022, 4, 5)
        ));
        flightList.add(new FlightDTO(4L,
                "Bolivia",
                "Perú",
                LocalDate.of(2022, 4, 15),
                LocalDate.of(2022, 4, 16)
        ));

        return flightList;
    }

    public static Flight findById(Long id){
        return new Flight(id,
                "Argentina",
                "Chile",
                LocalDate.of(2022, 1, 1),
                LocalDate.of(2022, 1, 1),
                null
        );
    }

    public static FlightDTO findByIdDTO(Long id){
        return new FlightDTO(id,
                "Argentina",
                "Chile",
                LocalDate.of(2022, 1, 1),
                LocalDate.of(2022, 1, 1)
        );
    }

    public static FlightDTO invalidDatesFlightDTO(){
        return new FlightDTO(null,
                "Argentina",
                "Chile",
                LocalDate.of(2022, 1, 1),
                LocalDate.of(2021, 1, 1)
        );
    }
}
