package com.globant.finalchallenge.tourismagency.util;

public interface CustomApiUserTop3Query {
    String getClientId();
    String getClientName();
    String getClientLastName();
    String getBookingQuantity();
    String getTotalAmount();
}
