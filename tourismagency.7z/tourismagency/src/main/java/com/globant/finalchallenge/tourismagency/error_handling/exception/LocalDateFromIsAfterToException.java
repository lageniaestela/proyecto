package com.globant.finalchallenge.tourismagency.error_handling.exception;

public class LocalDateFromIsAfterToException extends RuntimeException {
    private static final String DESCRIPTION = "Invalid Dates Exception";

    public LocalDateFromIsAfterToException(String detail){
        super(DESCRIPTION + ". " + detail);
    }
}
