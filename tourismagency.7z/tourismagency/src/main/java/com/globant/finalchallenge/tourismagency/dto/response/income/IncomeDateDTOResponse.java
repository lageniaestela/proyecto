package com.globant.finalchallenge.tourismagency.dto.response.income;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.globant.finalchallenge.tourismagency.util.serialization.CustomLocalDateSerializer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class IncomeDateDTOResponse extends IncomeDTOResponse{
        @JsonSerialize(using = CustomLocalDateSerializer.class)
        private LocalDate date;

        public IncomeDateDTOResponse(LocalDate theDate, Double totalBookingResp, Double totalFlightReservationResp) {
                super(totalBookingResp, totalFlightReservationResp);
                this.date = theDate;
        }
}
