package com.globant.finalchallenge.tourismagency.dto;

import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.Person;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class HotelBookingPersonDTO {
    private Long id;
    private Person person;
    private HotelBooking hotelBooking;
}
