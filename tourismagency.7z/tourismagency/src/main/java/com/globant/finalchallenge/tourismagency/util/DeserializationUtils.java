package com.globant.finalchallenge.tourismagency.util;

import com.fasterxml.jackson.core.JsonParser;
import lombok.SneakyThrows;

public abstract class DeserializationUtils {
    @SneakyThrows
    // formats the field path like this: booking.people[0].birthDate
    public static String getFullFieldJsonPathStr(JsonParser jsonParser) {
        String str = jsonParser.getParsingContext().pathAsPointer().toString();
        String[] tokens = str.substring(1).split("/"); // exclude initial /
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tokens.length; i++) {
            if (i > 0) {
                if (GlobalHelper.isNumeric(tokens[i]) && !GlobalHelper.isNumeric(tokens[i-1]))
                    sb.append(String.format("[%s]", tokens[i]));
                else
                    sb.append(".").append(tokens[i]);
            } else {
                sb.append(tokens[i]);
            }
        }
        return sb.toString();
    }
}
