package com.globant.finalchallenge.tourismagency.dto.request.flight_reservation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FlightReservationDTORequest {
    @Email
    private String userName;
    @Valid
    @NotNull
    private ReservationDTORequest flightReservation;
}
