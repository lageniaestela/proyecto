package com.globant.finalchallenge.tourismagency.service.implementation;

public class Benchmark {
}
