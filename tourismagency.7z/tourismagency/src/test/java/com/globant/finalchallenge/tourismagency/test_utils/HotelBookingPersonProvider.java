package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.model.HotelBooking;
import com.globant.finalchallenge.tourismagency.model.HotelBookingPerson;
import com.globant.finalchallenge.tourismagency.model.Person;

import java.time.LocalDate;
import java.util.List;

public abstract class HotelBookingPersonProvider {
    public static List<HotelBookingPerson> generateHotelBookingPeople() {
        Person jose = PersonProvider.generatePerson(1L, "1005221892",
                "Jose", "Acevedo",
                "sharp.acevedo@gmail.com");

        return List.of(
                new HotelBookingPerson(
                        1L,
                        jose,
                        new HotelBooking(1L, LocalDate.of(2021, 12, 24),
                                null, List.of(),
                                null, null)
                ),

                new HotelBookingPerson(
                        2L,
                        jose,
                        new HotelBooking(2L, LocalDate.of(2022, 1, 12),
                                null, List.of(),
                                null, null)
                )
        );
    }
}
