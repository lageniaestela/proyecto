package com.globant.finalchallenge.tourismagency.controller;


import com.globant.finalchallenge.tourismagency.dto.HotelDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.service.contract.IHotelService;
import com.globant.finalchallenge.tourismagency.service.implementation.HotelServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

@RequestMapping("hotels")
public class HotelController {
    private static final Logger logger = LoggerFactory.getLogger(HotelController.class);

    private final IHotelService hotelService;

    public HotelController(HotelServiceImpl hotelService) {
        this.hotelService = hotelService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<List<HotelDTO>> getHotels() {
        return ResponseEntity.ok()
                .body(hotelService.findAll());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<HotelDTO> getHotel(@PathVariable Long id) {
        return ResponseEntity.ok()
                .body(hotelService.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> saveHotel(@RequestBody @Validated HotelDTO hotelDTO) {
        SimpleCRUDResponseDTO responseDTO = hotelService.save(hotelDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> updateHotel(
            @PathVariable Long id,
            @RequestBody @Validated HotelDTO hotelDTO
    ) {
        SimpleCRUDResponseDTO responseDTO = hotelService.update(id, hotelDTO);

        return ResponseEntity.ok()
                .body(responseDTO);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_EMPLOYEE')")
    public ResponseEntity<SimpleCRUDResponseDTO> deleteHotel(@PathVariable Long id) {
        SimpleCRUDResponseDTO responseDTO = hotelService.delete(id);

        return ResponseEntity.ok()
                .body(responseDTO);
    }
}
