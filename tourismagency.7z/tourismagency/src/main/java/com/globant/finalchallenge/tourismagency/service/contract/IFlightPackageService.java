package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.FlightPackageDTO;

import com.globant.finalchallenge.tourismagency.dto.response.flight.FlightPackageResponseDTO;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;


import java.util.Optional;

public interface IFlightPackageService extends ICRUD<FlightPackageDTO,FlightPackageDTO> {
    Optional<FlightPackage> findByFlightPackageNumber(String flightNumber);

    FlightPackage save(FlightPackage flightPackage);
    FlightPackageResponseDTO getAllByFilter(Optional<String> dateFrom, Optional<String> dateTo, Optional<String> origin, Optional<String> destination);

}
