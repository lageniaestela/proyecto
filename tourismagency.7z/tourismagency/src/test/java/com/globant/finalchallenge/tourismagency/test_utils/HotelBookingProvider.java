package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.model.*;

import java.time.LocalDate;

public abstract class HotelBookingProvider {
    public static HotelBooking generateHotelBooking(Long id){
        return new HotelBooking(
                1L,
                LocalDate.of(2022, 3, 15),
                HotelPackageProvider.generatePackage(1),
                HotelBookingPersonProvider.generateHotelBookingPeople(),
                null,
                ApiUserProvider.generateApiUser(1L, "hola@gmail.com")
        );
    }
}
