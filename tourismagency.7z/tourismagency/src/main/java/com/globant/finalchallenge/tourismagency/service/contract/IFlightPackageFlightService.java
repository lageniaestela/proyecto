package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.ApiUserDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightPackageFlightDTO;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.FlightPackageFlight;

public interface IFlightPackageFlightService extends ICRUD<FlightPackageFlightDTO, FlightPackageFlightDTO>{
    FlightPackageFlight createFlightPackageFlightFromFlightDTO(FlightPackage flightPackage, FlightDTO flightDTO);
}
