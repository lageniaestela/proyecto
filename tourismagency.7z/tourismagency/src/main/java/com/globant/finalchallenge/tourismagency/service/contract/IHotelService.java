package com.globant.finalchallenge.tourismagency.service.contract;

import com.globant.finalchallenge.tourismagency.dto.HotelDTO;
import com.globant.finalchallenge.tourismagency.model.Hotel;
import org.springframework.stereotype.Service;

import java.util.Optional;

public interface IHotelService extends ICRUD<HotelDTO, HotelDTO>{
    Optional<Hotel> findByHotelCode(String hotelCode);
    boolean existsWithPlace(String place);
}
