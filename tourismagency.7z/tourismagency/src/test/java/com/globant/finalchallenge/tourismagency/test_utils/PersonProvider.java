package com.globant.finalchallenge.tourismagency.test_utils;

import com.globant.finalchallenge.tourismagency.model.Person;
import io.swagger.models.auth.In;

import java.time.LocalDate;
import java.util.List;

public abstract class PersonProvider {
    public static Person generatePerson(Long id, String dni, String firstName,
                                        String lastName, String mail) {
        return new Person(
                id,
                dni,
                firstName, lastName,
                LocalDate.of(2021, 7, 27),
                mail,
                List.of(),
                List.of(),
                null
        );
    }

        public static Person generatePerson(Integer number) {
            return new Person(
                    number.longValue(),
                    "dni" + number,
                    "firstName" + number,
                    "lastName" + number,
                    LocalDate.of(2021, 7, 27),
                    String.format("mail%s@mail.com", number),
                    null,
                    null,
                    null
            );
    }
}
