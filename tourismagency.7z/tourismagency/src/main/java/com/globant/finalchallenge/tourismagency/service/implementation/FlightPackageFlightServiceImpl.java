package com.globant.finalchallenge.tourismagency.service.implementation;

import com.globant.finalchallenge.tourismagency.dto.FlightDTO;
import com.globant.finalchallenge.tourismagency.dto.FlightPackageFlightDTO;
import com.globant.finalchallenge.tourismagency.dto.SimpleCRUDResponseDTO;
import com.globant.finalchallenge.tourismagency.error_handling.exception.InconsistentFlightData;
import com.globant.finalchallenge.tourismagency.error_handling.exception.ItemNotFoundException;
import com.globant.finalchallenge.tourismagency.error_handling.exception.NoItemsMatchQueryException;
import com.globant.finalchallenge.tourismagency.model.Flight;
import com.globant.finalchallenge.tourismagency.model.FlightPackage;
import com.globant.finalchallenge.tourismagency.model.FlightPackageFlight;
import com.globant.finalchallenge.tourismagency.repository.IFlightPackageFlightRepository;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightPackageFlightService;
import com.globant.finalchallenge.tourismagency.service.contract.IFlightService;
import com.globant.finalchallenge.tourismagency.util.GlobalHelper;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FlightPackageFlightServiceImpl implements IFlightPackageFlightService {
    private final IFlightPackageFlightRepository flightPackageFlightRepository;
    private final IFlightService flightService;
    private final ModelMapper modelMapper;

    public FlightPackageFlightServiceImpl(IFlightPackageFlightRepository flightPackageFlightRepository, IFlightService flightService, ModelMapper modelMapper) {
        this.flightPackageFlightRepository = flightPackageFlightRepository;
        this.flightService = flightService;
        this.modelMapper = modelMapper;
    }


    @Override
    public FlightPackageFlightDTO findById(Long id) {
        Optional<FlightPackageFlight> result = flightPackageFlightRepository.findById(id);

        if (result.isEmpty())
            throw new ItemNotFoundException("FlightPackageFlight", id.toString());

        return modelMapper.map(result.get(), FlightPackageFlightDTO.class);
    }

    @Override
    public List<FlightPackageFlightDTO> findAll() {
        List<FlightPackageFlight> flightPackageFlights = flightPackageFlightRepository.findAll();

        if (flightPackageFlights.isEmpty())
            throw new NoItemsMatchQueryException("flightPackageFlights");

        return flightPackageFlights.stream()
                .map(flightPackageFlight -> modelMapper.map(flightPackageFlight, FlightPackageFlightDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public SimpleCRUDResponseDTO save(FlightPackageFlightDTO flightPackageFlightDTO) {
        FlightPackageFlight flightPackageFlight = modelMapper.map(flightPackageFlightDTO, FlightPackageFlight.class);
        flightPackageFlight = flightPackageFlightRepository.save(flightPackageFlight);
        return GlobalHelper.createResponse(
                "FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.CREATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO update(Long id, FlightPackageFlightDTO flightPackageFlightDTO) {
        FlightPackageFlight flightPackageFlight = modelMapper.map(flightPackageFlightDTO, FlightPackageFlight.class);
        flightPackageFlight.setId(id);

        if (!flightPackageFlightRepository.existsById(id))
            throw new ItemNotFoundException("flightPackageFlight", id.toString());

        flightPackageFlight = flightPackageFlightRepository.save(flightPackageFlight);
        return GlobalHelper.createResponse(
                "FlightPackageFlight",
                flightPackageFlight.getId().toString(),
                GlobalHelper.CRUDActionType.UPDATED
        );
    }

    @Override
    public SimpleCRUDResponseDTO delete(Long id) {
        Optional<FlightPackageFlight> flightPackageFlight = flightPackageFlightRepository.findById(id);

        if (flightPackageFlight.isEmpty())
            throw new ItemNotFoundException("flightPackageFlight", id.toString());

        flightPackageFlightRepository.deleteById(flightPackageFlight.get().getId());
        return GlobalHelper.createResponse(
                "FlightPackageFlight",
                id.toString(),
                GlobalHelper.CRUDActionType.DELETED
        );
    }

    @Override
    public FlightPackageFlight createFlightPackageFlightFromFlightDTO(FlightPackage flightPackage, FlightDTO flightDTO) {
        FlightDTO persistedFlightDTO = flightService.findById(flightDTO.getId());

        if (!persistedFlightDTO.equals(flightDTO)){
            throw new InconsistentFlightData(flightDTO.getId());
        }

        FlightPackageFlight flightPackageFlight = new FlightPackageFlight();
        flightPackageFlight.setFlight(modelMapper.map(flightDTO, Flight.class));
        flightPackageFlight.setFlightPackage(flightPackage);
        return flightPackageFlight;
    }
}
